﻿Imports System.Data.SqlClient
Imports System.IO

Public Class _Default
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sStr As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sJScript As String = ""

        Try
            'Since it is very time consuming, load the json files only once a week
            If Not (IsPostBack) And DateDiff(DateInterval.Day, File.GetLastWriteTime(Server.MapPath("BadgeName.json")), Today.Date) >= 7 Then
                sJScript = "["
                sJScript = sJScript & LoadOperators()
                sJScript = sJScript & "]"
                System.IO.File.WriteAllText(Server.MapPath("BadgeName.json"), sJScript)

                sJScript = "["
                sJScript = sJScript & LoadBusLocations()
                sJScript = sJScript & "]"
                System.IO.File.WriteAllText(Server.MapPath("BusStopLocation.json"), sJScript)

                sJScript = "["
                sJScript = sJScript & LoadOCTADepartment()
                sJScript = sJScript & "]"
                System.IO.File.WriteAllText(Server.MapPath("OCTADepartment.json"), sJScript)

                sJScript = "["
                sJScript = sJScript & LoadContractDepartment()
                sJScript = sJScript & "]"
                System.IO.File.WriteAllText(Server.MapPath("ContractDepartment.json"), sJScript)
            End If

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Function LoadContractDepartment() As String
        Dim sDepartment As String = ""

        'This creates the OCTADepartment.json file used for look ups
        LoadContractDepartment = ""
        sSQL = "SELECT ID, IssueCategory, IssueCategoryAbbrev FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 AND IsCFR = 1 ORDER BY IssueCategory;"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            sDepartment = sDepartment & "{""department"": """ & Replace(Trim(dr("IssueCategory")), "'", "") & """, "
            sDepartment = sDepartment & """id"": """ & Replace(Trim(dr("ID")), "'", "") & """}, "
        Loop

        sDepartment = sDepartment.Substring(0, Len(sDepartment) - 2)

        oConn.Close()

        LoadContractDepartment = sDepartment

    End Function

    Private Function LoadOCTADepartment() As String
        Dim sDepartment As String = ""

        'This creates the OCTADepartment.json file used for look ups
        LoadOCTADepartment = ""
        sSQL = "SELECT ID, IssueCategory, IssueCategoryAbbrev FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 ORDER BY IssueCategory;"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            sDepartment = sDepartment & "{""department"": """ & Replace(Trim(dr("IssueCategory")), "'", "") & """, "
            sDepartment = sDepartment & """id"": """ & Replace(Trim(dr("ID")), "'", "") & """}, "
        Loop

        sDepartment = sDepartment.Substring(0, Len(sDepartment) - 2)

        oConn.Close()

        LoadOCTADepartment = sDepartment

    End Function

    Private Function LoadOperators() As String
        Dim sOperators As String = ""

        'This creates the BadgeName.json file used for look ups
        LoadOperators = ""
        sSQL = "Select LastName + ', ' + FirstName AS Operator, BadgeNum AS Badge "
        sSQL = sSQL & "From vwCoachOperatorsMasterList "
        sSQL = sSQL & "Where (ACTIVE = 1) AND "
        sSQL = sSQL & "((OrgID = 4) OR (OrgID = 3)) "
        sSQL = sSQL & "Order By FirstName, LastName"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            sOperators = sOperators & "{""name"": """ & Replace(dr("Operator"), "'", "") & """, "
            sOperators = sOperators & """badge"": """ & Replace(dr("Badge"), "'", "") & """}, "
        Loop

        sOperators = sOperators.Substring(0, Len(sOperators) - 2)

        oConn.Close()

        LoadOperators = sOperators

    End Function

    Private Function LoadBusLocations() As String
        Dim sLocations As String = ""

        Try
            'This creates the BusStopLocation.json file used for lookups
            LoadBusLocations = ""
            sSQL = "SELECT * FROM dbo.vwRI2BusStopInformation"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            'Display return value
            Do While dr.Read()
                sLocations = sLocations & "{""busstopLocation"": """ & Replace(IIf(IsDBNull(dr("Location")), "", dr("Location")), "'", "") & """, "
                sLocations = sLocations & """busstopID"": """ & IIf(IsDBNull(dr("OCTA_ID")), "", dr("OCTA_ID")) & """, "
                sLocations = sLocations & """lat"": """ & IIf(IsDBNull(dr("LAT")), "", dr("LAT")) & """, "
                sLocations = sLocations & """lon"": """ & IIf(IsDBNull(dr("LON")), "", dr("LON")) & """}, "
            Loop

            sLocations = sLocations.Substring(0, Len(sLocations) - 2)

            oConn.Close()

            LoadBusLocations = sLocations

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Function
End Class