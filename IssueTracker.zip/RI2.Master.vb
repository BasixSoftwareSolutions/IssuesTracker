﻿Imports System.Data.SqlClient
Imports System.Net.IPHostEntry
Imports System.Net

Public Class RI2
    Inherits System.Web.UI.MasterPage
    Dim sSQL As String
    Dim sConn As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()

        If Not IsPostBack Then
            Dim sNTUser As String
            Dim iPos As Integer
            Dim iSecurityGroup As Integer
            Dim bValidUser As Boolean = 0

            sNTUser = System.Web.HttpContext.Current.User.Identity.Name
            iPos = Len(sNTUser) - InStr(1, sNTUser, "\", 1)
            sNTUser = Right(sNTUser, iPos)
            sNTUser = "aalvidrez"
            Session("UserName") = sNTUser
            lblUser.Text = IIf(sNTUser = "", "Coach Operator", sNTUser)
            If sNTUser <> "" Then
                'Get the security level of the user
                sSQL = "SELECT TOP 1 SecurityGroup FROM tlkpRI2AdminMembers WHERE RTRIM(UserName) = '" & Trim(sNTUser) & "' AND Active = 1"
                sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
                Dim oConn As New SqlConnection(sConn)
                Dim oComm As New SqlCommand(sSQL, oConn)
                oComm.CommandType = CommandType.Text

                oConn.Open()

                Dim dr As SqlDataReader

                dr = oComm.ExecuteReader()

                Do While dr.Read()
                    iSecurityGroup = dr("SecurityGroup")
                    Session("SecurityGroup") = iSecurityGroup
                    Session("UserName") = sNTUser
                    bValidUser = 1
                Loop

                oConn.Close()
                oComm = Nothing

            End If
        End If

        Select Case Session("SecurityGroup")
            Case 1
                'Do nothing    
            Case 5
                Me.sysadmin.InnerHtml = "<span class='sidebarDisabled'></span>"
            Case Else
                Me.administration.InnerHtml = "<span class='sidebarDisabled'></span>"
                Me.sysadmin.InnerHtml = "<span class='sidebarDisabled'></span>"
        End Select

        Select Case Page.GetType().FullName
            Case Is = "ASP.default_aspx"
                Me.home.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-home'></i> Home </span>"
            Case Is = "ASP.input_aspx"
                Me.newrecord.InnerHtml = "<span class='sidebarInactive'><i class='far fa-edit'></i> Input New Record </span>"
            Case Is = "ASP.recordstatus_aspx"
                Me.status.InnerHtml = "<span class='sidebarInactive'><i class='far fa-question-circle'></i> Record Status </span>"
            Case Is = "ASP.history_aspx"
                Me.history.InnerHtml = "<span class='sidebarInactive'><i class='fas fa-history'></i> History </span>"
            Case Is = "ASP.uniformbalanceinquiry_aspx"
                Me.uniformbalance.InnerHtml = "<span class='sidebarInactive'><i class='fas fa-universal-access'></i> Uniform Balance </span>"
            Case Is = "ASP.recordselection_aspx"
                Me.administration.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-user'></i> Administration </span>"
            Case Is = "ASP.sysadmin_aspx"
                Me.sysadmin.InnerHtml = "<span class='sidebarInactive'><i class='fas fa-users-cog'></i> System Admin </span>"
            Case Else
                Me.home.InnerHtml = "<span class='sidebarInactive'><i class='fa fa-fw fa-home'></i> Home </span>"
        End Select

    End Sub


End Class