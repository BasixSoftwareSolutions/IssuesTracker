﻿Public Class BalanceReport
    Inherits System.Web.UI.Page

End Class