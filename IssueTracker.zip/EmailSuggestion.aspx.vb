﻿Imports System.Data.SqlClient
Imports System.Data
Public Class EmailSuggestion
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sStr As String

    Private Sub cmdEmail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEmail.Click

        SendEmail()

    End Sub
    Sub SendEmail()

        Try
            If Me.txtName.Text = " " Or Me.txtBadgeNumber.Text = "" Or txtBody.Text = "" Then
                litShowMessage.Visible = True
                Exit Sub
            End If

            sSQL = "spRI2SendEmail"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim vBody As New SqlParameter("@vchBody", SqlDbType.VarChar)
            oComm.Parameters.Add(vBody)
            vBody.Direction = ParameterDirection.Input
            vBody.Value = "From: " & Me.txtName.Text & " " & Me.txtBadgeNumber.Text & vbCrLf & vbCrLf & " - " & txtBody.Text

            Dim vTo As New SqlParameter("@vchTo", SqlDbType.VarChar)
            oComm.Parameters.Add(vTo)
            vTo.Direction = ParameterDirection.Input
            vTo.Value = System.Configuration.ConfigurationManager.AppSettings("EmailSuggestionAddress")

            oConn.Open()

            oComm.ExecuteReader()
            Response.Clear()
            Response.Write("<LINK href=""styles.css"" type=""text/css"" rel=""stylesheet"">")
            Response.Write("<script language=javascript>setTimeout(function () { window.close(); }, 3000);</script>")
            Response.Write("<div class=""container""><h3>Thank you, your suggestion has been sent.</h3></div>")
            Response.End()
            lblIssueType.Text = "Your email has been sent."

            Exit Sub

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

End Class