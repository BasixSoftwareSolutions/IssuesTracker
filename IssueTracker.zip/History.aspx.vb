﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Public Class History
    Inherits System.Web.UI.Page
    Dim sStr As String
    Dim sSQL As String
    Dim sConn As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Description:  User can filter or select records that have been inputted based. 
        '               on the dropdownbox criteria. Users can then drill down to the 
        '               detail record by selecting the record ID on the datagrid
        '
        ' Notes:    The query string uses the "AND" operator.
        '
        ' Revision History:
        ' ----------------------------------------------------------------------------
        '   Date         Name           Description
        ' ----------------------------------------------------------------------------
        '   06/30/05      Art Alvidrez   Initial Creation
        '

        If Request.QueryString("ID") <> "" Then
            Exit Sub
        End If

        'Load the dropdownboxes
        If Not IsPostBack Then
            LoadRoute()
            LoadStopID()
            LoadStatus()
            LoadIssueCategory()
        End If

    End Sub
    Private Sub LoadIssueCategory()

        sSQL = "SELECT ID, IssueCategory, IssueCategoryAbbrev FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 ORDER BY SortOrder; "

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        'Load Route
        With cboIssueCategory
            .DataSource = oReader
            .DataTextField = "IssueCategory"
            .DataValueField = "ID"
            .DataBind()
        End With

        'Reset combobox
        cboIssueCategory.Items.Insert(0, "")

        oReader.Close()
        oConn.Close()

    End Sub
    Private Sub LoadStatus()

        'Load the Status dropdownbox
        sSQL = "spRI2GetStatus"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboStatus.DataSource = oReader
        cboStatus.DataTextField = "Status"
        cboStatus.DataValueField = "Status"
        cboStatus.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the Combobox
        cboStatus.Items.Insert(0, "")

    End Sub

    Private Sub LoadStopID()

        'Load the Stop ID dropdownbox
        sSQL = "SELECT DISTINCT StopID FROM dbo.vwRI2IssueRecord WHERE not(StopID) IS NULL ORDER BY StopID"
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboStopID
            .DataSource = oReader
            .DataTextField = "StopID"
            .DataValueField = "StopID"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset the Combobox
        cboStopID.Items.Insert(0, "")

    End Sub

    Private Sub LoadRoute()

        'Load the Route dropdownbox
        sSQL = "SELECT DISTINCT Route FROM dbo.vwRI2IssueRecord WHERE NOT(Route) IS NULL ORDER BY Route"
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboRoute
            .DataSource = oReader
            .DataTextField = "Route"
            .DataValueField = "Route"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset the Combobox
        cboRoute.Items.Insert(0, "")

    End Sub
    Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClear.Click

        'Clear all of the comboboxes and hide the datagrid
        cboID.Text = ""
        cboStopID.SelectedIndex = 0
        cboBadge.Text = ""
        cboRoute.SelectedIndex = 0
        cboOperator.Text = ""
        cboIssueCategory.SelectedIndex = 0
        cboStatus.SelectedIndex = 0
        If cboIssue.Visible Then cboIssue.SelectedIndex = 0
        mdgRecordList.Visible = False
        lblHeader.Visible = False

    End Sub

    Sub SortGrid(ByVal sSortField As String)

        'Sort recordset by column selected by user
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        If ViewState("SortDirection") = "DESC" Then
            Source.Sort = sSortField & " ASC"
            ViewState("SortDirection") = "ASC"
        Else
            Source.Sort = sSortField & " DESC"
            ViewState("SortDirection") = "DESC"
        End If

        mdgRecordList.DataSource = Source
        mdgRecordList.DataBind()

    End Sub

    Public Sub cmdSearchGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearchGo.Click

        'Create the query string using the "AND" operator between parameters
        Dim sCriteria As String

        'Clear the variable
        sCriteria = ""

        Try
            If cboStopID.SelectedItem.Text <> "" Then
                sCriteria = sCriteria & "StopID = " & CInt(cboStopID.SelectedItem.Text) & " AND "
            End If
            If cboBadge.Text <> "" Then
                sCriteria = sCriteria & "Badge = " & CInt(cboBadge.Text) & " AND "
            End If
            If cboRoute.SelectedItem.Text <> "" Then
                sCriteria = sCriteria & "Route = " & CInt(cboRoute.SelectedItem.Text) & " AND "
            End If
            If cboOperator.Text <> "" Then
                sCriteria = sCriteria & "Operator = '" & CStr(cboOperator.Text) & "' AND "
            End If
            If cboIssueCategory.SelectedItem.Text <> "" Then
                sCriteria = sCriteria & "TypeOfIssueID = '" & CStr(cboIssueCategory.SelectedItem.Value) & "' AND "
            End If
            If cboIssue.Visible Then
                If cboIssue.SelectedItem.Text <> "" Then
                    sCriteria = sCriteria & "RTRIM(Issue) = '" & Trim(cboIssue.SelectedItem.Text.ToString) & "' AND "
                End If
            End If
            If cboStatus.SelectedItem.Text <> "" Then
                sCriteria = sCriteria & "Status = '" & CStr(cboStatus.SelectedItem.Text) & "' AND "
            End If

            sSQL = "SELECT * FROM vwRI2IssueRecord "

            'Strip off the last AND
            If sCriteria <> "" Then
                sCriteria = Left(sCriteria, Len(sCriteria) - 5)
                sSQL = sSQL & "WHERE " & sCriteria & " ORDER BY DateOfOccurrence DESC"
            Else
                Exit Sub
            End If
            txtSQL.Text = sSQL
            ViewState("SortDirection") = "DESC"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            'Check for returned records
            If RcdCount = 0 Then
                mdgRecordList.Visible = False
                lblNoRecords.Visible = True
                lblHeader.Visible = False
            Else
                lblHeader.Visible = True
                mdgRecordList.Visible = True
                lblNoRecords.Visible = False
                mdgRecordList.DataSource = oDataSet.Tables.Item("dtRecordList")
                mdgRecordList.DataBind()
            End If

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Protected Sub mdgRecordList_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles mdgRecordList.Sorting
        'Sort the datagrid
        SortGrid(e.SortExpression)

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Page function
        mdgRecordList.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            mdgRecordList.Visible = False
            lblNoRecords.Visible = True
        Else
            mdgRecordList.Visible = True
            lblNoRecords.Visible = False
            mdgRecordList.DataSource = oDataSet.Tables.Item("dtRecordList")
            mdgRecordList.DataBind()
        End If
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

        ' Verifies that the control is rendered

    End Sub

    Protected Sub cmdExportToExcel_Click(sender As Object, e As EventArgs)

        Try
            If mdgRecordList.Rows.Count = 0 Then Exit Sub

            Response.ClearContent()
            Response.Buffer = True
            Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "RI2Export.xls"))
            Response.ContentType = "application/ms-excel"

            Dim sw As New StringWriter()
            Dim htw As New HtmlTextWriter(sw)

            mdgRecordList.HeaderRow.Style.Add("background-color", "#FFFFFF")

            For i As Integer = 0 To mdgRecordList.HeaderRow.Cells.Count - 1
                mdgRecordList.HeaderRow.Cells(i).Style.Add("background-color", "#df5015")
            Next

            mdgRecordList.RenderControl(htw)
            Response.Write(sw.ToString())
            Response.[End]()

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub cboIssueCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboIssueCategory.SelectedIndexChanged

        If cboIssueCategory.SelectedValue = "" Then Exit Sub

        sSQL = "Select ID, Issue "
        sSQL = sSQL & "From dbo.tlkpRI2IssueType "
        sSQL = sSQL & "Where Active = 1 "
        sSQL = sSQL & "And IssueCategoryID = " & cboIssueCategory.SelectedValue & " "
        sSQL = sSQL & "ORDER BY Issue"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboIssue
            .DataSource = oReader
            .DataTextField = "Issue"
            .DataValueField = "ID"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset the Combobox
        cboIssue.Items.Insert(0, "")
        cboIssue.Visible = True
        lblIssue.Visible = True

    End Sub

    Private Sub ViewDetail(iID As Integer)

        Try
            'Load the detail record based on the value entered or selected.
            sSQL = "spRI2GetIssueRecord"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iIssueID As New SqlParameter("@iIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iIssueID)
            iIssueID.Direction = ParameterDirection.Input
            iIssueID.Value = iID

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dvRecordDetails.DataSource = dr
            dvRecordDetails.DataBind()
            dr.Close()

            dr = oComm.ExecuteReader()

            Do While dr.Read()

                If IsDBNull(dr("BaseName")) Then
                    dvRecordDetails.Rows(9).Cells(0).Visible = False
                    dvRecordDetails.Rows(9).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Route")) Then
                    dvRecordDetails.Rows(10).Cells(0).Visible = False
                    dvRecordDetails.Rows(10).Cells(1).Visible = False
                End If
                If IsDBNull(dr("RouteDirection")) Then
                    dvRecordDetails.Rows(11).Cells(0).Visible = False
                    dvRecordDetails.Rows(11).Cells(1).Visible = False
                End If
                If IsDBNull(dr("StopID")) Then
                    dvRecordDetails.Rows(12).Cells(0).Visible = False
                    dvRecordDetails.Rows(12).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Location")) Then
                    dvRecordDetails.Rows(13).Cells(0).Visible = False
                    dvRecordDetails.Rows(13).Cells(1).Visible = False
                End If
                If IsDBNull(dr("WorkRun")) Then
                    dvRecordDetails.Rows(14).Cells(0).Visible = False
                    dvRecordDetails.Rows(14).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusRun")) Then
                    dvRecordDetails.Rows(15).Cells(0).Visible = False
                    dvRecordDetails.Rows(15).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusNumber")) Then
                    dvRecordDetails.Rows(16).Cells(0).Visible = False
                    dvRecordDetails.Rows(16).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusSeries")) Then
                    dvRecordDetails.Rows(17).Cells(0).Visible = False
                    dvRecordDetails.Rows(17).Cells(1).Visible = False
                End If
                If IsDBNull(dr("DayType")) Then
                    dvRecordDetails.Rows(18).Cells(0).Visible = False
                    dvRecordDetails.Rows(18).Cells(1).Visible = False
                End If
            Loop

            dvRecordDetails.Visible = True

            oConn.Close()
            dr.Close()
            oComm = Nothing

            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub cboID_TextChanged(sender As Object, e As EventArgs) Handles cboID.TextChanged
        Dim sStr As String = ""
        Dim sBadge As String = ""

        'Build the query string using the selected parameteres
        If cboID.Text <> "" Then
            sSQL = "SELECT * FROM vwRI2IssueRecord WHERE ID = " & cboID.Text & " ORDER BY ID DESC"
        Else
            Exit Sub
        End If

        txtSQL.Text = sSQL

        Dim oConn As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("RI2_Conn"))
        oConn.Open()

        Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            mdgRecordList.Visible = False
        Else
            mdgRecordList.Visible = True
            mdgRecordList.DataSource = oDataSet.Tables.Item("dtRecordList")
            mdgRecordList.DataBind()
        End If

    End Sub

    Private Sub mdgRecordList_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles mdgRecordList.RowCommand

        If (e.CommandName = "ViewDetail") Then
            Dim Index As Integer = Convert.ToInt32(e.CommandArgument)
            Dim Row As GridViewRow = mdgRecordList.Rows(Index)

            ViewDetail(Row.Cells(1).Text)
        End If

    End Sub
End Class