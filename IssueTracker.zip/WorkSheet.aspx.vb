Imports System.Data.SqlClient
Imports System.Data

Partial Class WorkSheet
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sStr As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Description:  This is the worksheet page that the Admin users will use to
        '               respond to issues. All of the original input fields are locked 
        '               and can not be edited. Admin users can change fields in the 
        '               dropdownlist and update the Narrative field.
        '
        ' Notes:    
        '
        ' Revision History:
        ' ----------------------------------------------------------------------------
        '   Date         Name           Description
        ' ----------------------------------------------------------------------------
        '   06/30/05      Art Alvidrez   Initial Creation
        '

        cboAssignedTo.Attributes("onchange") = "on()"

        'Load the dropdownlists
        If Not IsPostBack Then
            LoadAssignedTo()
            LoadStatus()
            LoadIssueCategory()
            LoadRecord()
        End If

    End Sub

    Private Sub LoadIssueCategory()

        'Load the Issue dropdownlist
        sSQL = "SELECT ID, RTRIM(IssueCategory) AS IssueCategory FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 ORDER BY SortOrder"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboIssueType.DataSource = oReader
        cboIssueType.DataTextField = "IssueCategory"
        cboIssueType.DataValueField = "ID"
        cboIssueType.DataBind()

        oReader.Close()
        oConn.Close()
        oComm = Nothing

    End Sub

    Private Sub LoadIssueDropDown(ByVal sIssueType As String)

        'Load the Issue dropdownlist
        sSQL = "EXECUTE spRI2GetIssueType '" & sIssueType & "'"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboIssue.DataSource = oReader
        cboIssue.DataTextField = "Issue"
        cboIssue.DataValueField = "ID"
        cboIssue.DataBind()

        oReader.Close()
        oConn.Close()
        oComm = Nothing

    End Sub

    Private Sub LoadMapIt(ByVal sStopID As String)

        If lblStopID.Text <> "" And lblStopID.Text <> "0" Then
            sSQL = "SELECT Lat, Lon FROM dbo.tblLatLonStopNo WHERE Stop_No = " & sStopID & ""
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            'Check each field for null values 
            Do While dr.Read()
                If Not IsDBNull(dr("Lat")) And Not IsDBNull(dr("Lon")) Then
                    Me.hlMapIt.Visible = True
                    Me.hlMapIt.NavigateUrl = "MapIt.aspx?Lat=" & dr("Lat") & "&Long=" & dr("Lon") & "&Desc='" & lblLocation.Text & "'"
                Else
                    Me.hlMapIt.Visible = False
                End If
            Loop

            oConn.Close()
            dr.Close()
            oComm = Nothing
        Else
            Me.hlMapIt.Visible = False
        End If

    End Sub

    Private Sub LoadRecord()
        'Load the record
        Dim sIssueType As String = ""
        Dim sIssueTypeDesc As String = ""
        Dim sMsg As String = ""
        Dim sStopID As String = ""
        Dim iIssueCategoryID As Integer

        Try
            sSQL = "spRI2GetIssueRecord"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            'Set the parameter value from the ID passed in
            Dim iIssueID As SqlParameter = oComm.Parameters.Add("@iIssueID", SqlDbType.Int)
            iIssueID.Value = CInt(Request.QueryString("ID"))

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            'Check each field for null values 
            Do While dr.Read()
                Session("RecordID") = CInt(Request.QueryString("ID"))
                If Not IsDBNull(dr("TypeOfIssueID")) Then
                    LoadIssueDropDown(dr("TypeOfIssueID"))
                    cboIssueType.SelectedIndex = cboIssueType.Items.IndexOf(cboIssueType.Items.FindByValue(dr("TypeOfIssueID").ToString))
                    cboIssue.SelectedIndex = cboIssue.Items.IndexOf(cboIssue.Items.FindByValue(dr("IssueTypeID")))
                    sIssueType = dr("IssueCategoryAbbrev")
                    iIssueCategoryID = dr("TypeOfIssueID")
                    sIssueTypeDesc = dr("TypeOfIssue")
                    lblIssueType.Text = dr("TypeOfIssue") & " Issue"
                    sMsg = "Issue Type: " & sIssueTypeDesc & vbCrLf
                End If

                lblID.Text = dr("ID")
                sMsg = ""
                sMsg = sMsg & "ID Number: " & dr("ID") & vbCrLf
                If Not IsDBNull(dr("Status")) Then
                    cboStatus.SelectedIndex = cboStatus.Items.IndexOf(cboStatus.Items.FindByText(dr("Status").ToString))
                    sMsg = sMsg & "Status: " & dr("Status") & vbCrLf
                End If
                If Not IsDBNull(dr("Status")) Then Session("Status") = cboStatus.SelectedItem.Value
                If Not IsDBNull(dr("Badge")) Then
                    lblBadge.Text = dr("Badge")
                    sMsg = sMsg & "Badge Number: " & lblBadge.Text & vbCrLf
                End If
                If Not IsDBNull(dr("Operator")) Then
                    lblOperator.Text = dr("Operator")
                    sMsg = sMsg & "Operator Name: " & lblOperator.Text & vbCrLf
                End If
                If Not IsDBNull(dr("EnteredBy")) Then
                    lblEnteredBy.Text = dr("EnteredBy")
                    sMsg = sMsg & "Entered By: " & lblEnteredBy.Text & vbCrLf
                End If
                If Not IsDBNull(dr("DateOfOccurrence")) Then
                    lblDateOfOccurrence.Text = dr("DateOfOccurrence")
                    sMsg = sMsg & "Date of Occurrence: " & lblDateOfOccurrence.Text & vbCrLf
                End If
                If Not IsDBNull(dr("TimeOfOccurrence")) Then
                    lblTimeOfOccurrence.Text = dr("TimeOfOccurrence")
                    sMsg = sMsg & "Time of Occurrence: " & lblTimeOfOccurrence.Text & vbCrLf
                End If
                If Not IsDBNull(dr("CreatedDate")) Then
                    lblEnteredDate.Text = dr("CreatedDate")
                    sMsg = sMsg & "Entered Date: " & lblEnteredDate.Text & vbCrLf
                End If
                If Not IsDBNull(dr("DueDate")) Then
                    lblDueDate.Text = dr("DueDate")
                    sMsg = sMsg & "Due Date: " & lblDueDate.Text & vbCrLf
                End If
                If Not IsDBNull(dr("BaseName")) Then
                    lblBase.Text = dr("BaseName").ToString
                    sMsg = sMsg & "Base: " & dr("BaseName").ToString & vbCrLf
                    tdRow1Col1.Visible = True
                    tdRow1Col2.Visible = True
                Else
                    tdRow1Col1.Visible = False
                    tdRow1Col2.Visible = False
                End If
                If Not IsDBNull(dr("Route")) Then
                    lblRoute.Text = dr("Route").ToString
                    sMsg = sMsg & "Route: " & lblRoute.Text & vbCrLf
                    tdRow2Col1.Visible = True
                    tdRow2Col2.Visible = True
                Else
                    tdRow2Col1.Visible = False
                    tdRow2Col2.Visible = False
                End If
                If Not IsDBNull(dr("RouteDirection")) Then
                    lblRouteDir.Text = dr("RouteDirection").ToString
                    sMsg = sMsg & "Route Direction: " & lblRouteDir.Text & vbCrLf
                Else
                    tdRow3Col1.Visible = False
                    tdRow3Col2.Visible = False
                End If
                If Not IsDBNull(dr("BusRun")) Then
                    lblBusRun.Text = dr("BusRun").ToString
                    sMsg = sMsg & "Bus Run: " & lblBusRun.Text & vbCrLf
                    tdRow6Col1.Visible = True
                    tdRow6Col2.Visible = True
                Else
                    tdRow6Col1.Visible = False
                    tdRow6Col2.Visible = False
                End If
                If Not IsDBNull(dr("WorkRun")) Then
                    lblWorkRun.Text = dr("WorkRun").ToString
                    sMsg = sMsg & "Work Run: " & lblWorkRun.Text & vbCrLf
                    tdRow7Col1.Visible = True
                    tdRow7Col2.Visible = True
                Else
                    tdRow7Col1.Visible = False
                    tdRow7Col2.Visible = False
                End If
                If Not IsDBNull(dr("DayType")) Then
                    lblDayType.Text = dr("DayType").ToString
                    sMsg = sMsg & "Day Type: " & lblDayType.Text & vbCrLf
                    tdRow10Col1.Visible = True
                    tdRow10Col2.Visible = True
                Else
                    tdRow10Col1.Visible = False
                    tdRow10Col2.Visible = False
                End If
                If Not IsDBNull(dr("BusNumber")) Then
                    lblBusNumber.Text = dr("BusNumber").ToString
                    sMsg = sMsg & "Bus Number: " & lblBusNumber.Text & vbCrLf
                    tdRow8Col1.Visible = True
                    tdRow8Col2.Visible = True
                Else
                    tdRow8Col1.Visible = False
                    tdRow8Col2.Visible = False
                End If
                If Not IsDBNull(dr("BusSeries")) Then
                    lblBusSeries.Text = dr("BusSeries").ToString
                    sMsg = sMsg & "Bus Number: " & lblBusSeries.Text & vbCrLf
                    tdRow9Col1.Visible = True
                    tdRow9Col2.Visible = True
                Else
                    tdRow9Col1.Visible = False
                    tdRow9Col2.Visible = False
                End If
                If Not IsDBNull(dr("Description")) Then
                    lblDescription.Text = dr("Description").ToString
                    sMsg = sMsg & "Description: " & dr("Description").ToString & vbCrLf
                End If
                If Not IsDBNull(dr("StopID")) Then
                    lblStopID.Text = dr("StopID").ToString
                    sStopID = dr("StopID").ToString
                    sMsg = sMsg & "Stop ID#: " & lblStopID.Text & vbCrLf
                    tdRow4Col1.Visible = True
                    tdRow4Col2.Visible = True
                Else
                    tdRow4Col1.Visible = False
                    tdRow4Col2.Visible = False
                End If
                If Not IsDBNull(dr("Location")) Then
                    lblLocation.Text = dr("Location").ToString
                    sMsg = sMsg & "Stop Location: " & lblLocation.Text & vbCrLf
                    tdRow5Col1.Visible = True
                    tdRow5Col2.Visible = True
                Else
                    tdRow5Col1.Visible = False
                    tdRow5Col2.Visible = False
                End If
                If Not IsDBNull(dr("AdminName")) Then
                    cboAssignedTo.SelectedIndex = cboAssignedTo.Items.IndexOf(cboAssignedTo.Items.FindByValue(dr("AssignedToAdminID").ToString))
                    sMsg = sMsg & "Assigned To: " & Trim(dr("AdminName")).ToString & vbCrLf
                End If
                If Not IsDBNull(dr("NarrativeDate")) Then
                    txtNarrative.Text = dr("NarrativeDate").ToString
                    sMsg = sMsg & "Narrative Date: " & dr("NarrativeDate") & vbCrLf
                End If
                If Not IsDBNull(dr("Narrative")) Then
                    txtNarrative.Text = dr("Narrative").ToString
                    sMsg = sMsg & "Narrative: " & dr("Narrative") & vbCrLf
                End If

                Session("EmailMsg") = sMsg
            Loop

            oConn.Close()
            dr.Close()
            oComm = Nothing

            If sStopID = "" Or sStopID = "0" Then
                Me.hlMapIt.Visible = False
            Else
                LoadMapIt(sStopID)
                Me.hlMapIt.Visible = True
            End If

            'Set the form for the appropriate issue type
            LoadCannedTextButtons(iIssueCategoryID)

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub
    Private Sub LoadAssignedTo()

        'Load the Assigned To dropdownlist
        sSQL = "spRI2GetAdminList"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboAssignedTo.DataSource = oReader
        cboAssignedTo.DataTextField = "AdminGroup"
        cboAssignedTo.DataValueField = "ID"
        cboAssignedTo.DataBind()

        oReader.Close()
        oConn.Close()
        oComm = Nothing

    End Sub

    Private Sub LoadStatus()
        'Load the Status dropdownlist
        sSQL = "spRI2GetStatus"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboStatus.DataSource = oReader
        cboStatus.DataTextField = "Status"
        cboStatus.DataValueField = "ID"
        cboStatus.DataBind()

        oReader.Close()
        oConn.Close()
        oComm = Nothing

    End Sub

    Public Sub SaveRecord(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.lblSuccess.Visible = False
        'Get the NT user name to assign to the NarrativeBy field
        Dim sNTUser As String
        Dim iPos As Integer

        sNTUser = RTrim(Request.ServerVariables("LOGON_USER"))
        iPos = Len(sNTUser) - InStr(1, sNTUser, "\", 1)
        sNTUser = Right(sNTUser, iPos)

        Try

            'Set the parameter values
            sSQL = "spRI2UpdateRecord"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iRecordID As New SqlParameter("@iRecordID", SqlDbType.Int)
            oComm.Parameters.Add(iRecordID)
            iRecordID.Direction = ParameterDirection.Input
            iRecordID.Value = CInt(lblID.Text)

            Dim chIsuseType As New SqlParameter("@chIsuseType", SqlDbType.NChar)
            oComm.Parameters.Add(chIsuseType)
            chIsuseType.Direction = ParameterDirection.Input
            chIsuseType.Value = CStr(cboIssueType.SelectedItem.Value)

            Dim iStatus As New SqlParameter("@iStatus", SqlDbType.Int)
            oComm.Parameters.Add(iStatus)
            iStatus.Direction = ParameterDirection.Input
            iStatus.Value = CInt(cboStatus.SelectedItem.Value)

            Dim iAssignedTo As New SqlParameter("@iAssignedTo", SqlDbType.Int)
            oComm.Parameters.Add(iAssignedTo)
            iAssignedTo.Direction = ParameterDirection.Input
            iAssignedTo.Value = CInt(cboAssignedTo.SelectedItem.Value)

            Dim iIssue As New SqlParameter("@iIssue", SqlDbType.Int)
            oComm.Parameters.Add(iIssue)
            iIssue.Direction = ParameterDirection.Input
            iIssue.Value = CInt(cboIssue.SelectedItem.Value)

            'Add the current time/date stamp to the narrative
            Dim dCurrentDateTime As DateTime = DateTime.Now
            Dim strCurrentDateTime As String
            strCurrentDateTime = dCurrentDateTime.ToString()

            Dim vchNarrative As New SqlParameter("@vchNarrative", SqlDbType.NVarChar)
            oComm.Parameters.Add(vchNarrative)
            vchNarrative.Direction = ParameterDirection.Input
            vchNarrative.Value = RI2v2.Utilities.fStripSpecialChar(CStr(txtNarrative.Text)) & vbCrLf & "*** By: " & sNTUser & " - " & strCurrentDateTime & " ***"

            Dim chAdmin As New SqlParameter("@chAdmin", SqlDbType.NVarChar)
            oComm.Parameters.Add(chAdmin)
            chAdmin.Direction = ParameterDirection.Input
            chAdmin.Value = CStr(sNTUser)

            Dim iReturnValue As New SqlParameter("@iReturnValue", SqlDbType.Int)
            oComm.Parameters.Add(iReturnValue)
            iReturnValue.Direction = ParameterDirection.Output

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            If oComm.Parameters("@iReturnValue").Value Then
                'Send email if complete
                If (cboStatus.SelectedItem.Value <> Session("Status")) And (cboStatus.SelectedItem.Value = 3 Or cboStatus.SelectedItem.Value = 4 Or cboStatus.SelectedItem.Value = 5) Then
                    'Send email
                    SendEmailNotice(CInt(lblID.Text))
                End If
                'Display message
                Me.lblSuccess.Visible = True
            End If

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub SendEmailNotice(ByVal iIssueID As Integer)

        Try
            sSQL = "spRI2SendCompletedEmail"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iRecordID As New SqlParameter("@iRecordID", SqlDbType.Int)
            oComm.Parameters.Add(iRecordID)
            iRecordID.Direction = ParameterDirection.Input
            iRecordID.Value = CInt(iIssueID)

            oConn.Open()

            oComm.ExecuteReader()

            oConn.Close()

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub LoadCannedTextButtons(ByVal iIssueCategoryID As Integer)
        Dim i As Integer = 1

        Try
            pVerbage.Controls.Clear()

            sSQL = "SELECT ID, ButtonText, CannedText FROM dbo.tlkpRI2CannedText WHERE Active = 1 AND IssueCategoryID = '" & iIssueCategoryID & "' ORDER BY ButtonText"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()
            If (dr.HasRows) Then
                Dim HeaderLabel As New Label
                HeaderLabel.Width = 800
                HeaderLabel.CssClass = "PageTitle"
                HeaderLabel.Text = "Canned Verbiage"
                pVerbage.Controls.Add(HeaderLabel)
                pVerbage.Controls.Add(New LiteralControl("<table id='table8' cellpadding='5px' style='width: 75%'><tr>"))
            End If

            Do While dr.Read()
                Dim cmdTextBtn As New LinkButton
                cmdTextBtn.ID = "cmdTextBtn" & dr("ID")
                cmdTextBtn.Text = dr("ButtonText")
                cmdTextBtn.Width = 250
                cmdTextBtn.OnClientClick = "javascript:(cannedVerbaige('" & dr("CannedText") & "'));return false"
                cmdTextBtn.ToolTip = dr("CannedText")
                cmdTextBtn.CssClass = "button"
                cmdTextBtn.CausesValidation = False
                If i Mod 3 = 1 Then
                    pVerbage.Controls.Add(New LiteralControl("</tr><tr>"))
                End If
                pVerbage.Controls.Add(New LiteralControl("<td style='width: 33%'>"))
                pVerbage.Controls.Add(cmdTextBtn)
                pVerbage.Controls.Add(New LiteralControl("</td>"))
                i = i + 1
            Loop
            pVerbage.Controls.Add(New LiteralControl("</tr></table>"))

            oConn.Close()
            dr.Close()
            oComm = Nothing

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub CannedText_OnClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim btnText As String

        btnText = DirectCast(sender, Button).ToolTip
        txtNarrative.Text = LTrim(txtNarrative.Text & " " & btnText)

    End Sub

    Private Sub cboIssueType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboIssueType.SelectedIndexChanged
        sSQL = "Select ID, Issue "
        sSQL = sSQL & "From dbo.tlkpRI2IssueType "
        sSQL = sSQL & "Where Active = 1 "
        sSQL = sSQL & "And IssueCategoryID = " & cboIssueType.SelectedValue & " "
        sSQL = sSQL & "ORDER BY Issue"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboIssue.DataSource = oReader
        cboIssue.DataTextField = "Issue"
        cboIssue.DataValueField = "ID"
        cboIssue.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        cboIssue.Items.Insert(0, "")

        LoadCannedTextButtons(Trim(cboIssueType.SelectedValue))

    End Sub

    Private Sub cmdGetRecord_Click(sender As Object, e As EventArgs) Handles cmdGetRecord.Click

        If txtRecordID.Text <> "" Then Response.Redirect("WorkSheet.aspx?ID=" & CInt(txtRecordID.Text) & "")

    End Sub

    Private Sub cmdPrint_Click(sender As Object, e As EventArgs) Handles cmdPrint.Click
        'Load the detail record based on the value entered or selected.
        sSQL = "spRI2GetIssueRecord"

        Try
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iIssueID As New SqlParameter("@iIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iIssueID)
            iIssueID.Direction = ParameterDirection.Input
            iIssueID.Value = CInt(Me.lblID.Text)

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dvRecordDetails.DataSource = dr
            dvRecordDetails.DataBind()
            dr.Close()

            dr = oComm.ExecuteReader()

            Do While dr.Read()

                If IsDBNull(dr("BaseName")) Then
                    dvRecordDetails.Rows(9).Cells(0).Visible = False
                    dvRecordDetails.Rows(9).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Route")) Then
                    dvRecordDetails.Rows(10).Cells(0).Visible = False
                    dvRecordDetails.Rows(10).Cells(1).Visible = False
                End If
                If IsDBNull(dr("RouteDirection")) Then
                    dvRecordDetails.Rows(11).Cells(0).Visible = False
                    dvRecordDetails.Rows(11).Cells(1).Visible = False
                End If
                If IsDBNull(dr("StopID")) Then
                    dvRecordDetails.Rows(12).Cells(0).Visible = False
                    dvRecordDetails.Rows(12).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Location")) Then
                    dvRecordDetails.Rows(13).Cells(0).Visible = False
                    dvRecordDetails.Rows(13).Cells(1).Visible = False
                End If
                If IsDBNull(dr("WorkRun")) Then
                    dvRecordDetails.Rows(14).Cells(0).Visible = False
                    dvRecordDetails.Rows(14).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusRun")) Then
                    dvRecordDetails.Rows(15).Cells(0).Visible = False
                    dvRecordDetails.Rows(15).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusNumber")) Then
                    dvRecordDetails.Rows(16).Cells(0).Visible = False
                    dvRecordDetails.Rows(16).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusSeries")) Then
                    dvRecordDetails.Rows(17).Cells(0).Visible = False
                    dvRecordDetails.Rows(17).Cells(1).Visible = False
                End If
                If IsDBNull(dr("DayType")) Then
                    dvRecordDetails.Rows(18).Cells(0).Visible = False
                    dvRecordDetails.Rows(18).Cells(1).Visible = False
                End If
            Loop

            dvRecordDetails.Visible = True

            oConn.Close()
            dr.Close()
            oComm = Nothing

            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub
End Class
