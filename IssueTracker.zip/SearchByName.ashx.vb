﻿Imports System
Imports System.Web
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Text
Imports System.Net.WebClient

Public Class SearchByName
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim prefixText As String = context.Request.QueryString("q")
        Dim conn As SqlConnection = New SqlConnection
        conn.ConnectionString = ConfigurationManager.ConnectionStrings("RI2_Conn").ConnectionString
        Dim cmd As SqlCommand = New SqlCommand
        cmd.CommandText = ("SELECT ID,  rtrim(UPPER(Operator)) + ' - ' + CONVERT(char(5), ID) + ' - ' +  CONVERT(Char(10), CreatedDate, 101) as RecordList From dbo.vwRI2IssueRecord Where rtrim(UPPER(Operator)) + ' - ' + CONVERT(char(5), ID) + ' - ' +  CONVERT(Char(10), CreatedDate, 101) like '%' + @SearchText + '%' Order By ID DESC")
        cmd.Parameters.AddWithValue("@SearchText", prefixText)
        cmd.Connection = conn
        Dim sb As StringBuilder = New StringBuilder
        conn.Open()
        Dim sdr As SqlDataReader = cmd.ExecuteReader
        While sdr.Read
            sb.Append(sdr("RecordList")).Append(Environment.NewLine)
        End While
        conn.Close()
        context.Response.Write(sb.ToString)

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class