Imports System.Data.SqlClient
Imports System.Data
Imports System.IO

Partial Class RecordSelection
    Inherits System.Web.UI.Page
    Dim sConn As String
    Dim sSQL As String
    Dim sStr As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        ' Description:  From here an Admin user can select the record they want to work on.
        '               They can either filter or select a recordset to work on.
        '
        ' Notes:    The filtered recordset uses the "AND" operator between criteria.
        '
        ' Revision History:
        ' ----------------------------------------------------------------------------
        '   Date         Name           Description
        ' ----------------------------------------------------------------------------
        '   06/30/05      Art Alvidrez   Initial Creation
        '
        If Request.QueryString("GoBack") = "true" Then
            Dim oConn As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("RI2_Conn"))
            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(Session("SQL"), oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            mdgListOfRecords.Visible = True
            mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
            mdgListOfRecords.DataBind()
            lbExportToExcel.Visible = True
        End If

        'Load all of the dropdownboxes
        If Not IsPostBack Then
            LoadRoute()
            LoadAdmin()
            LoadIssueCategory()
            LoadStatus()
        End If
    End Sub

    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        mdgListOfRecords.DataSource = Source
        mdgListOfRecords.DataBind()

    End Sub

    Private Sub LoadIssueCategory()

        'Load the Issue dropdownlist
        sSQL = "SELECT ID, RTRIM(IssueCategory) AS IssueCategory FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 ORDER BY SortOrder"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboIssueType.DataSource = oReader
        cboIssueType.DataTextField = "IssueCategory"
        cboIssueType.DataValueField = "ID"
        cboIssueType.DataBind()

        oReader.Close()
        oConn.Close()
        oComm = Nothing

        cboIssueType.Items.Insert("0", "All")

    End Sub

    Private Sub LoadRoute()

        'Load the Route dropdownbox
        sSQL = "SELECT Line as Route FROM dbo.[List Of Lines] ORDER BY Line"
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboRoute
            .DataSource = oReader
            .DataTextField = "Route"
            .DataValueField = "Route"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset dropdownbox to null
        cboRoute.Items.Insert(0, "All")

    End Sub

    Private Sub LoadStatus()

        'Load the Status dropdownbox
        sSQL = "spRI2GetStatus"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboStatus.DataSource = oReader
        cboStatus.DataTextField = "Status"
        cboStatus.DataValueField = "ID"
        cboStatus.DataBind()

        oReader.Close()
        oConn.Close()

        cboStatus.Items.Insert(0, "All")

    End Sub

    Private Sub LoadAdmin()

        'Load the Admin dropdownbox
        sSQL = "spRI2GetAdminList"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.StoredProcedure

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboAdmin.DataSource = oReader
        cboAdmin.DataTextField = "AdminGroup"
        cboAdmin.DataValueField = "ID"
        cboAdmin.DataBind()

        oReader.Close()
        oConn.Close()

        'Add the item 'All' to the list
        'Reset dropdownbox to 'All'
        cboAdmin.Items.Insert(0, "All")
        cboAdmin.SelectedIndex = 0

    End Sub
    Public Sub cmdFilterGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFilterGo.Click
        Dim sStr As String = ""
        Dim sCriteria As String = ""
        Dim sBadge As String = ""
        Me.lblWarning.Visible = False

        Try
            'Build the query string with the selected parameters
            sSQL = "SELECT * FROM vwRI2IssueRecord "

            If cboStatus.SelectedItem.Text <> "All" Then
                sCriteria = sCriteria & "Status = '" & cboStatus.SelectedItem.Text & "' AND "
            End If
            If cboIssueType.SelectedItem.Text <> "All" Then
                sCriteria = sCriteria & "TypeOfIssueID = " & cboIssueType.SelectedItem.Value & " AND "
            End If
            If cboAdmin.SelectedItem.Text <> "All" Then
                sCriteria = sCriteria & "AdminID = " & cboAdmin.SelectedValue & " AND "
            End If
            If cboOperator.Text <> "" Then
                sBadge = Trim(Left(Me.cboOperator.Text, InStr(Me.cboOperator.Text, " ")))
                If sBadge <> "" Then
                    sCriteria = sCriteria & "Badge = " & sBadge & " AND "
                Else
                    Me.lblWarning.Visible = True
                    Exit Sub
                End If
            End If

            If cboRoute.SelectedItem.Text <> "All" Then
                sCriteria = sCriteria & "Route = " & cboRoute.SelectedItem.Value & " AND "
            End If

            If sCriteria <> "" Then
                sCriteria = sCriteria.Substring(0, Len(sCriteria) - 5)
                sSQL = sSQL & " WHERE " & sCriteria & " ORDER BY ID DESC"
            Else
                sSQL = sSQL & " ORDER BY ID DESC"
            End If

            txtSQL.Text = sSQL
            Session("SQL") = sSQL

            Dim oConn As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("RI2_Conn"))
            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            If RcdCount = 0 Then
                mdgListOfRecords.Visible = False
                lbExportToExcel.Visible = False
            Else
                litShowMessage.Visible = False
                mdgListOfRecords.Visible = True
                mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
                mdgListOfRecords.DataBind()
                lbExportToExcel.Visible = True
            End If

            Session("WhichButton") = "cmdFilterGo"

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClear.Click

        'Clear all of the textboxes
        'Hide the appropriate panel
        cboID.Text = ""
        cboRoute.SelectedIndex = 0
        cboOperator.Text = ""
        cboIssueType.SelectedIndex = 0
        cboStatus.SelectedIndex = 0
        cboAdmin.SelectedIndex = 0
        mdgListOfRecords.Visible = False
        litShowMessage.Visible = False

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        mdgListOfRecords.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            mdgListOfRecords.Visible = False
        Else
            litShowMessage.Visible = False
            mdgListOfRecords.Visible = True
            mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
            mdgListOfRecords.DataBind()
        End If
    End Sub

    Private Sub cmdViewOverdue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdViewOverdue.Click
        Try

            'Set the parameter values
            sSQL = "SELECT * FROM dbo.vwRI2IssueRecord  WHERE DueDate <GETDATE() AND Status IN('Received', 'Under Study')	ORDER BY ID"

            'Store the SQL string in case the user wants to sort the datagrid
            txtSQL.Text = sSQL
            Session("SQL") = sSQL

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            If RcdCount = 0 Then
                litShowMessage.Visible = True
                mdgListOfRecords.Visible = False
            Else
                litShowMessage.Visible = False
                mdgListOfRecords.Visible = True
                mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
                mdgListOfRecords.DataBind()
                lbExportToExcel.Visible = True
            End If

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Protected Sub mdgListOfRecords_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles mdgListOfRecords.Sorting
        'Sort the datagrid
        SortGrid(e.SortExpression)

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As Control)

        ' Verifies that the control is rendered

    End Sub
    Protected Sub cmdExportExcel_Click(sender As Object, e As EventArgs)

        Try
            Response.ClearContent()
            Response.Buffer = True
            Response.AddHeader("content-disposition", String.Format("attachment; filename={0}", "RI2Export.xls"))
            Response.ContentType = "application/ms-excel"

            Dim sw As New StringWriter()
            Dim htw As New HtmlTextWriter(sw)

            mdgListOfRecords.AllowPaging = False

            If Session("WhichButton") <> Nothing Then
                cmdFilterGo_Click("cmdFilterGo", Nothing)
            End If

            mdgListOfRecords.HeaderRow.Style.Add("background-color", "#FFFFFF")

            For i As Integer = 0 To mdgListOfRecords.HeaderRow.Cells.Count - 1
                mdgListOfRecords.HeaderRow.Cells(i).Style.Add("background-color", "#df5015")
            Next

            mdgListOfRecords.RenderControl(htw)
            Response.Write(sw.ToString())
            Response.[End]()

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub cboID_TextChanged(sender As Object, e As EventArgs) Handles cboID.TextChanged
        Dim sStr As String = ""
        Dim sCriteria As String = ""
        Dim sBadge As String = ""
        Me.lblWarning.Visible = False

        Try
            'Build the query string using the selected parameteres
            If cboID.Text <> "" Then
                sSQL = "SELECT * FROM vwRI2IssueRecord WHERE ID = " & CInt(cboID.Text) & " ORDER BY ID DESC"
            Else
                Me.lblWarning.Visible = True
                Exit Sub
            End If

            txtSQL.Text = sSQL
            Session("SQL") = sSQL

            Dim oConn As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("RI2_Conn"))
            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            If RcdCount = 0 Then
                mdgListOfRecords.Visible = False
            Else
                mdgListOfRecords.Visible = True
                mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
                mdgListOfRecords.DataBind()
            End If

            Session("WhichButton") = "cmdSearchGo"

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub ViewDetailRecord(iRecordID As Integer)

        Try
            Dim oConn As New SqlConnection(System.Configuration.ConfigurationManager.AppSettings("RI2_Conn"))
            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(Session("SQL"), oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            mdgListOfRecords.Visible = True
            mdgListOfRecords.DataSource = oDataSet.Tables.Item("dtRecordList")
            mdgListOfRecords.DataBind()
            lbExportToExcel.Visible = True
            oConn.Close()

            'Load the detail record based on the value entered or selected.
            sSQL = "spRI2GetIssueRecord"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iIssueID As New SqlParameter("@iIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iIssueID)
            iIssueID.Direction = ParameterDirection.Input
            iIssueID.Value = CInt(iRecordID)

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dvRecordDetails.DataSource = dr
            dvRecordDetails.DataBind()
            dr.Close()

            dr = oComm.ExecuteReader()

            Do While dr.Read()

                If IsDBNull(dr("BaseName")) Then
                    dvRecordDetails.Rows(9).Cells(0).Visible = False
                    dvRecordDetails.Rows(9).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Route")) Then
                    dvRecordDetails.Rows(10).Cells(0).Visible = False
                    dvRecordDetails.Rows(10).Cells(1).Visible = False
                End If
                If IsDBNull(dr("RouteDirection")) Then
                    dvRecordDetails.Rows(11).Cells(0).Visible = False
                    dvRecordDetails.Rows(11).Cells(1).Visible = False
                End If
                If IsDBNull(dr("StopID")) Then
                    dvRecordDetails.Rows(12).Cells(0).Visible = False
                    dvRecordDetails.Rows(12).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Location")) Then
                    dvRecordDetails.Rows(13).Cells(0).Visible = False
                    dvRecordDetails.Rows(13).Cells(1).Visible = False
                End If
                If IsDBNull(dr("WorkRun")) Then
                    dvRecordDetails.Rows(14).Cells(0).Visible = False
                    dvRecordDetails.Rows(14).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusRun")) Then
                    dvRecordDetails.Rows(15).Cells(0).Visible = False
                    dvRecordDetails.Rows(15).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusNumber")) Then
                    dvRecordDetails.Rows(16).Cells(0).Visible = False
                    dvRecordDetails.Rows(16).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusSeries")) Then
                    dvRecordDetails.Rows(17).Cells(0).Visible = False
                    dvRecordDetails.Rows(17).Cells(1).Visible = False
                End If
                If IsDBNull(dr("DayType")) Then
                    dvRecordDetails.Rows(18).Cells(0).Visible = False
                    dvRecordDetails.Rows(18).Cells(1).Visible = False
                End If
            Loop

            dvRecordDetails.Visible = True

            oConn.Close()
            dr.Close()
            oComm = Nothing

            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub mdgListOfRecords_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles mdgListOfRecords.RowCommand

        If e.CommandName = "ViewCmd" Then
            ViewDetailRecord(CInt(e.CommandArgument))
        End If

    End Sub
End Class
