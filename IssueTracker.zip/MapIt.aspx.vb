
Partial Class MapIt
    Inherits System.Web.UI.Page

End Class
