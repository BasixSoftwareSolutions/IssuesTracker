
Partial Class ZoomSV
    Inherits System.Web.UI.Page

End Class
