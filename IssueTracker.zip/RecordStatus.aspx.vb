﻿Imports System.Data.SqlClient
Imports System.Data


Public Class RecordStatus
    Inherits System.Web.UI.Page
    Dim sConn As String
    Dim sSQL As String
    Dim sStr As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Description:  This page is used to provide status for any all records. 
        '               Users can either select from the dropdownbox or enter the ID 
        '               in the text box. The detail record with the current status
        '               will then appear below.
        '
        ' Notes:    
        '
        ' Revision History:
        ' ----------------------------------------------------------------------------
        '   Date         Name           Description
        ' ----------------------------------------------------------------------------
        '   06/30/05      Art Alvidrez   Initial Creation
        '
        If Not IsPostBack Then
            'If the user hits enter default to the Go button
            ClientScript.RegisterHiddenField("_EVENTTARGET", "cmdGo")
        End If

    End Sub

    Private Sub LoadRecord(ByVal iRecordID As Int32)

        Try
            Me.lblWarning.Visible = False

            'Load the detail record based on the value entered or selected.
            sSQL = "spRI2GetIssueRecord"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iIssueID As New SqlParameter("@iIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iIssueID)
            iIssueID.Direction = ParameterDirection.Input
            iIssueID.Value = iRecordID

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dvRecordDetails.DataSource = dr
            dvRecordDetails.DataBind()
            dr.Close()

            dr = oComm.ExecuteReader()

            Do While dr.Read()

                If IsDBNull(dr("BaseName")) Then
                    dvRecordDetails.Rows(9).Cells(0).Visible = False
                    dvRecordDetails.Rows(9).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Route")) Then
                    dvRecordDetails.Rows(10).Cells(0).Visible = False
                    dvRecordDetails.Rows(10).Cells(1).Visible = False
                End If
                If IsDBNull(dr("RouteDirection")) Then
                    dvRecordDetails.Rows(11).Cells(0).Visible = False
                    dvRecordDetails.Rows(11).Cells(1).Visible = False
                End If
                If IsDBNull(dr("StopID")) Then
                    dvRecordDetails.Rows(12).Cells(0).Visible = False
                    dvRecordDetails.Rows(12).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Location")) Then
                    dvRecordDetails.Rows(13).Cells(0).Visible = False
                    dvRecordDetails.Rows(13).Cells(1).Visible = False
                End If
                If IsDBNull(dr("WorkRun")) Then
                    dvRecordDetails.Rows(14).Cells(0).Visible = False
                    dvRecordDetails.Rows(14).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusRun")) Then
                    dvRecordDetails.Rows(15).Cells(0).Visible = False
                    dvRecordDetails.Rows(15).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusNumber")) Then
                    dvRecordDetails.Rows(16).Cells(0).Visible = False
                    dvRecordDetails.Rows(16).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusSeries")) Then
                    dvRecordDetails.Rows(17).Cells(0).Visible = False
                    dvRecordDetails.Rows(17).Cells(1).Visible = False
                End If
                If IsDBNull(dr("DayType")) Then
                    dvRecordDetails.Rows(18).Cells(0).Visible = False
                    dvRecordDetails.Rows(18).Cells(1).Visible = False
                End If
            Loop

            hfRecordID.Value = iRecordID
            dvRecordDetails.Visible = True

            oConn.Close()
            dr.Close()
            oComm = Nothing

            txtRecordID.Text = ""
            txtSearchName.Text = ""

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub txtSearchName_TextChanged(sender As Object, e As EventArgs) Handles txtSearchName.TextChanged
        Dim iRecordID As Integer = 0

        'Get the record selected from the dropdownlist
        If Len(txtSearchName.Text) > 6 Then
            iRecordID = CInt(Me.txtSearchName.Text.Substring(InStr(Me.txtSearchName.Text, "-") + 1, 5))
        End If

        If iRecordID = 0 Then
            Exit Sub
        End If
        LoadRecord(iRecordID)

    End Sub

    Private Sub txtRecordID_TextChanged(sender As Object, e As EventArgs) Handles txtRecordID.TextChanged
        Dim iRecordID As Integer = 0

        'Get the record selected from the dropdownlist
        If Len(txtRecordID.Text) > 4 Then
            iRecordID = CInt(Me.txtRecordID.Text)
        End If

        If iRecordID = 0 Then
            Exit Sub
        End If
        LoadRecord(iRecordID)

    End Sub
End Class