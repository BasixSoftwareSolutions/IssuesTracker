﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Configuration
Public Class Input
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sStr As String
    Dim strRequiredBackgroundColor As String = System.Configuration.ConfigurationManager.AppSettings("RequiredBackground")
    Dim strOptionalBackgroundColor As String = System.Configuration.ConfigurationManager.AppSettings("OptionalBackground")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            Me.lblWarning.Visible = False
            Me.lblSuccess.Visible = False

            If Not (IsPostBack) Then
                LoadIssueCategory()
                LoadDropDownList()
                Me.txtBadge.Focus()
                Me.txtDateOfOccurrence.Text = Date.Today().ToShortDateString
                Dim dt As New DataTable()
                gvCategoryAndSubCategories.DataSource = GetData("SELECT IssueCategory, Issue FROM dbo.vwRI2CategoryList GROUP BY IssueCategory, Issue ORDER BY IssueCategory, Issue")
                gvCategoryAndSubCategories.DataBind()
                gvSubCategoriesAndCategory.DataSource = GetData("SELECT IssueCategory, Issue FROM dbo.vwRI2CategoryList GROUP BY Issue, IssueCategory  ORDER BY Issue, IssueCategory")
                gvSubCategoriesAndCategory.DataBind()
                If Request.QueryString("RecordID") <> "" Then
                    PrintRecord()
                End If
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' style='width:100%' Visible='true'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try

    End Sub
    Private Sub LoadIssueCategory()

        sSQL = "SELECT ID, IssueCategory, IssueCategoryAbbrev FROM dbo.tlkpRI2IssueCategory WHERE Active = 1 ORDER BY IssueCategory; "

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        'Load Route
        With cboIssueCategory
            .DataSource = oReader
            .DataTextField = "IssueCategory"
            .DataValueField = "ID"
            .DataBind()
        End With

        'Reset combobox
        cboIssueCategory.Items.Insert(0, "")

        oReader.Close()
        oConn.Close()
    End Sub
    Private Sub LoadDropDownList()

        'Load the Route, Bus Run and Work Run dropdownboxes
        sSQL = "SELECT Line as Route FROM dbo.[List Of Lines] ORDER BY Line; " &
        "SELECT [Bus Run] FROM dbo.[Bus Runs] GROUP BY [Bus Run] ORDER BY [Bus Run]; " &
        "SELECT [Work Run] FROM dbo.[Work Runs] ORDER BY [Work Run]; "

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        'Load Route
        With cboRoute
            .DataSource = oReader
            .DataTextField = "Route"
            .DataBind()
        End With

        'Reset combobox
        cboRoute.Items.Insert(0, "")

        oReader.NextResult()

        'Load Bus Run
        With cboBusRun
            .DataSource = oReader
            .DataTextField = "Bus Run"
            .DataValueField = "Bus Run"
            .DataBind()
        End With

        'Reset combobox
        cboBusRun.Items.Insert(0, "")

        oReader.NextResult()

        'Load Work Run
        With cboWorkRun
            .DataSource = oReader
            .DataTextField = "Work Run"
            .DataValueField = "Work Run"
            .DataBind()
        End With

        'Reset combobox
        cboWorkRun.Items.Insert(0, "")

        oReader.Close()
        oConn.Close()

    End Sub

    Private Sub cboIssueCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboIssueCategory.SelectedIndexChanged

        Me.txtDescription.Text = ""

        sSQL = "Select ID, Issue "
        sSQL = sSQL & "From dbo.tlkpRI2IssueType "
        sSQL = sSQL & "Where Active = 1 "
        sSQL = sSQL & "And IssueCategoryID = " & Trim(cboIssueCategory.SelectedValue) & " "
        sSQL = sSQL & "ORDER BY Issue"

        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        cboIssueType.DataSource = oReader
        cboIssueType.DataTextField = "Issue"
        cboIssueType.DataValueField = "ID"
        cboIssueType.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        cboIssueType.Items.Insert(0, "")

        pnlIssueInfo.Visible = True

        SetBackground()

    End Sub

    Private Sub SetBackground()
        On Error Resume Next

        RequiredBackground.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
        OptionalBackground.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)

        'Reset backcolor
        cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboRoute.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboRouteDir.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboBusRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboWorkRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboDayType.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        txtStopID.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        txtStopLocation.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        txtBusNumber.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        cboBusSeries.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)

        Dim sIssueCategory = Trim(cboIssueCategory.SelectedValue)
        Select Case sIssueCategory
            Case Is = 1, Is = 11, Is = 12, Is = 13, Is = 14
                If cboBase.SelectedValue <> "" Then
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboRoute.SelectedValue <> "" Then
                    cboRoute.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboRoute.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboRouteDir.SelectedValue <> "" Then
                    cboRouteDir.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboRouteDir.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboBusRun.SelectedValue <> "" Then
                    cboBusRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboBusRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboWorkRun.SelectedValue <> "" Then
                    cboWorkRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboWorkRun.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboDayType.SelectedValue <> "" Then
                    cboDayType.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboDayType.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If

                cboBase.Attributes.Add("required", "true")
                cboRoute.Attributes.Add("required", "true")
                cboRouteDir.Attributes.Add("required", "true")
                cboBusRun.Attributes.Add("required", "true")
                cboWorkRun.Attributes.Add("required", "true")
                cboDayType.Attributes.Add("required", "true")
                txtStopID.Attributes.Remove("required")
                txtStopLocation.Attributes.Remove("required")
                txtBusNumber.Attributes.Remove("required")
                cboBusSeries.Attributes.Remove("required")
            Case Is = 2
                If txtStopID.Text <> "" Then
                    txtStopID.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    txtStopID.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If txtStopLocation.Text <> "" Then
                    txtStopLocation.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    txtStopLocation.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboRoute.SelectedValue <> "" Then
                    cboRoute.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboRoute.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboRouteDir.SelectedValue <> "" Then
                    cboRouteDir.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboRouteDir.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                cboBase.Attributes.Remove("required")
                cboBusRun.Attributes.Remove("required")
                cboWorkRun.Attributes.Remove("required")
                cboDayType.Attributes.Remove("required")
                txtStopID.Attributes.Add("required", "true")
                txtStopLocation.Attributes.Add("required", "true")
                txtBusNumber.Attributes.Remove("required")
                cboBusSeries.Attributes.Remove("required")
            Case Is = 3, Is = 4
                If txtStopID.Text <> "" Then
                    txtStopID.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    txtStopID.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If txtStopLocation.Text <> "" Then
                    txtStopLocation.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    txtStopLocation.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If

                cboBase.Attributes.Remove("required")
                cboRoute.Attributes.Remove("required")
                cboRouteDir.Attributes.Remove("required")
                cboBusRun.Attributes.Remove("required")
                cboWorkRun.Attributes.Remove("required")
                cboDayType.Attributes.Remove("required")
                txtStopID.Attributes.Add("required", "true")
                txtStopLocation.Attributes.Add("required", "true")
                txtBusNumber.Attributes.Remove("required")
                cboBusSeries.Attributes.Remove("required")
            Case Is = 8, Is = 9, Is = 6, Is = 7
                If cboBase.SelectedValue <> "" Then
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If

                cboBase.Attributes.Add("required", "true")
                cboRoute.Attributes.Remove("required")
                cboRouteDir.Attributes.Remove("required")
                cboBusRun.Attributes.Remove("required")
                cboWorkRun.Attributes.Remove("required")
                cboDayType.Attributes.Remove("required")
                txtStopID.Attributes.Remove("required")
                txtStopLocation.Attributes.Remove("required")
                txtBusNumber.Attributes.Remove("required")
                cboBusSeries.Attributes.Remove("required")
            Case Is = 10
                If cboBase.SelectedValue <> "" Then
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboBase.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If txtBusNumber.Text <> "" Then
                    txtBusNumber.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    txtBusNumber.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If
                If cboBusSeries.SelectedValue <> "" Then
                    cboBusSeries.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
                Else
                    cboBusSeries.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
                End If

                cboBase.Attributes.Add("required", "true")
                cboRoute.Attributes.Remove("required")
                cboRouteDir.Attributes.Remove("required")
                cboBusRun.Attributes.Remove("required")
                cboWorkRun.Attributes.Remove("required")
                cboDayType.Attributes.Remove("required")
                txtStopID.Attributes.Remove("required")
                txtStopLocation.Attributes.Remove("required")
                txtBusNumber.Attributes.Add("required", "true")
                cboBusSeries.Attributes.Add("required", "true")
        End Select

        If txtDescription.Text = "" Then
            txtDescription.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
        Else
            txtDescription.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        End If
        If cboIssueType.SelectedValue = "" Then
            cboIssueType.BackColor = System.Drawing.ColorTranslator.FromHtml(strRequiredBackgroundColor)
        Else
            cboIssueType.BackColor = System.Drawing.ColorTranslator.FromHtml(strOptionalBackgroundColor)
        End If

    End Sub
    Private Sub cboIssueType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboIssueType.SelectedIndexChanged

        Me.txtDescription.Text = ""
        lblMessage.Text = ""

        sSQL = "SELECT [SuppQuestions], [Message] FROM [dbo].[tlkpRI2IssueType] WHERE ID = " & cboIssueType.SelectedValue & ""
        sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            If Not IsDBNull(dr("SuppQuestions")) Then
                txtDescription.Text = dr("SuppQuestions")
            End If
            If Not IsDBNull(dr("Message")) Then
                lblMessage.Text = dr("Message")
                lblMessage.Visible = True
            Else
                lblMessage.Visible = False
            End If
        Loop

        oConn.Close()
        dr.Close()
        oComm = Nothing

        'SetBackground()

    End Sub

    Private Function GetAssignedTo() As Int32
        Dim sCriteria As String = ""
        Dim iIssueCategoryID As String = cboIssueCategory.SelectedValue
        sSQL = ""
        GetAssignedTo = 0

        Try
            'Assign the issue to an Analyst based on issue type. If Issue Type is SP
            'then its based on route or SP type of issue. 
            Select Case iIssueCategoryID
                Case Is = 1
                    If cboRoute.SelectedValue <> "" Then
                        sSQL = "SELECT AdminID AS ID FROM dbo.tlkpRI2RouteAssignments WHERE Route = " & CInt(cboRoute.SelectedValue) & ""
                    Else
                        GetAssignedTo = 98
                        Exit Function
                    End If
                Case Else
                    sCriteria = "IssueCategoryID = " & iIssueCategoryID & " AND PrimaryAssigned = 1 AND Active = 1"
                    sSQL = "SELECT ID FROM dbo.vwRI2AssignedTo WHERE " & sCriteria & ""
            End Select

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            Do While dr.Read()
                GetAssignedTo = dr("ID")
            Loop

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Function

    Private Sub cmdSubmit_Click(sender As Object, e As EventArgs) Handles cmdSubmit.Click
        Try
            'Set the parameter values for the issue and insert the record
            sSQL = "spRI2InsertIssueRecord"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iBadge As New SqlParameter("@iBadge", SqlDbType.Int)
            oComm.Parameters.Add(iBadge)
            iBadge.Direction = ParameterDirection.Input
            iBadge.Value = CInt(txtBadge.Text)

            Dim chrCoachOperator As New SqlParameter("@chrCoachOperator", SqlDbType.NChar)
            oComm.Parameters.Add(chrCoachOperator)
            chrCoachOperator.Direction = ParameterDirection.Input
            chrCoachOperator.Value = RTrim(CStr(txtCoachOperator.Text))

            Dim chrEnteredBy As New SqlParameter("@chrEnteredBy", SqlDbType.NChar)
            oComm.Parameters.Add(chrEnteredBy)
            chrEnteredBy.Direction = ParameterDirection.Input
            chrEnteredBy.Value = RTrim(CStr(txtEnteredBy.Text))

            Dim dDateOfOccurrence As New SqlParameter("@dDateOfOccurrence", SqlDbType.DateTime)
            oComm.Parameters.Add(dDateOfOccurrence)
            dDateOfOccurrence.Direction = ParameterDirection.Input
            dDateOfOccurrence.Value = CDate(txtDateOfOccurrence.Text)

            Dim iTimeOfOccurrence As New SqlParameter("@iTimeOfOccurrence", SqlDbType.Int)
            oComm.Parameters.Add(iTimeOfOccurrence)
            iTimeOfOccurrence.Direction = ParameterDirection.Input
            iTimeOfOccurrence.Value = CInt(txtTimeOfOccurrence.Text)

            Dim iTypeOfIssueID As New SqlParameter("@iTypeOfIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iTypeOfIssueID)
            iTypeOfIssueID.Direction = ParameterDirection.Input
            iTypeOfIssueID.Value = CInt(cboIssueCategory.SelectedValue)

            Dim iAssignedToID As New SqlParameter("@iAssignedToID", SqlDbType.Int)
            oComm.Parameters.Add(iAssignedToID)
            iAssignedToID.Direction = ParameterDirection.Input
            iAssignedToID.Value = GetAssignedTo()

            If cboBase.SelectedValue <> "" Then
                Dim iBase As New SqlParameter("@iBase", SqlDbType.Int)
                oComm.Parameters.Add(iBase)
                iBase.Direction = ParameterDirection.Input
                iBase.Value = CInt(cboBase.SelectedValue)
            End If

            If cboRoute.SelectedValue <> "" Then
                Dim iRoute As New SqlParameter("@iRoute", SqlDbType.Int)
                oComm.Parameters.Add(iRoute)
                iRoute.Direction = ParameterDirection.Input
                iRoute.Value = CInt(cboRoute.SelectedValue)
            End If

            If cboRouteDir.Text <> "" Then
                Dim vchRouteDir As New SqlParameter("@vchRouteDir", SqlDbType.NVarChar)
                oComm.Parameters.Add(vchRouteDir)
                vchRouteDir.Direction = ParameterDirection.Input
                vchRouteDir.Value = CStr(cboRouteDir.SelectedValue)
            End If

            If txtStopID.Text <> "" Then
                Dim iStopID As New SqlParameter("@iStopID", SqlDbType.Int)
                oComm.Parameters.Add(iStopID)
                iStopID.Direction = ParameterDirection.Input
                iStopID.Value = CInt(txtStopID.Text)
            End If

            If txtStopLocation.Text <> "" Then
                Dim vchLocation As New SqlParameter("@vchLocation", SqlDbType.NVarChar)
                oComm.Parameters.Add(vchLocation)
                vchLocation.Direction = ParameterDirection.Input
                vchLocation.Value = RI2v2.Utilities.fStripSpecialChar(CStr(txtStopLocation.Text))
            End If

            If cboBusRun.SelectedValue <> "" Then
                Dim iBusRun As New SqlParameter("@iBusRun", SqlDbType.Int)
                oComm.Parameters.Add(iBusRun)
                iBusRun.Direction = ParameterDirection.Input
                iBusRun.Value = CInt(cboBusRun.SelectedValue)
            End If

            If cboWorkRun.SelectedValue <> "" Then
                Dim iWorkRun As New SqlParameter("@iWorkRun", SqlDbType.Int)
                oComm.Parameters.Add(iWorkRun)
                iWorkRun.Direction = ParameterDirection.Input
                iWorkRun.Value = CInt(cboWorkRun.SelectedValue)
            End If

            If txtBusNumber.Text <> "" Then
                Dim iBusNumber As New SqlParameter("@iBusNumber", SqlDbType.Int)
                oComm.Parameters.Add(iBusNumber)
                iBusNumber.Direction = ParameterDirection.Input
                iBusNumber.Value = CInt(txtBusNumber.Text)
            End If

            If cboBusSeries.SelectedValue <> "" Then
                Dim vchBusSeries As New SqlParameter("@vchBusSeries", SqlDbType.NVarChar)
                oComm.Parameters.Add(vchBusSeries)
                vchBusSeries.Direction = ParameterDirection.Input
                vchBusSeries.Value = CStr(cboBusSeries.SelectedValue)
            End If

            If cboDayType.SelectedValue <> "" Then
                Dim chDayType As New SqlParameter("@chDayType", SqlDbType.NVarChar)
                oComm.Parameters.Add(chDayType)
                chDayType.Direction = ParameterDirection.Input
                chDayType.Value = CStr(cboDayType.SelectedValue)
            End If

            If cboIssueType.SelectedValue <> "" Then
                Dim iIssueTypeID As New SqlParameter("@iIssueTypeID", SqlDbType.Int)
                oComm.Parameters.Add(iIssueTypeID)
                iIssueTypeID.Direction = ParameterDirection.Input
                iIssueTypeID.Value = CInt(cboIssueType.SelectedValue)
            End If

            Dim vchDescription As New SqlParameter("@vchDescription", SqlDbType.NVarChar)
            oComm.Parameters.Add(vchDescription)
            vchDescription.Direction = ParameterDirection.Input
            vchDescription.Value = RI2v2.Utilities.fStripSpecialChar(CStr(txtDescription.Text))

            Dim iRecordID As New SqlParameter("@iReturnValue", SqlDbType.Int)
            oComm.Parameters.Add(iRecordID)
            iRecordID.Direction = ParameterDirection.Output

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            If oComm.Parameters("@iReturnValue").Value Then
                'Display message
                Session("RecordID") = oComm.Parameters("@iReturnValue").Value
                Call ClearForm()
                Me.pnlIssueInfo.Visible = False
                Me.cboIssueCategory.SelectedIndex = 0
                lblSuccess.Visible = True
                Me.lblSuccess.InnerHtml = "<span id='lblSuccess' runat='server' Class='success' visible='true' style='width:100%'><i class='far fa-thumbs-up'></i> RI2 record# <span style='color:red'>" & Session("RecordID") & "</span> has been saved and submitted...<img src='images/spacer.gif' style='width:120px; height:2px' /><a href='Input.aspx?RecordID=" & Session("RecordID") & "'>Print Record</a></span>"
            End If

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
            Dim lblWarning As HtmlGenericControl = FindControl("lblWarning")
            Me.lblWarning.InnerHtml = "<span class='warning' ID='lblWarning' runat='server' style='width:100%' Visible='true'><i class='fa fa-warning'></i>" & ex.Message & "</span>"
            Me.lblWarning.Visible = True
        End Try

    End Sub

    Private Sub ClearForm()

        txtBadge.Text = ""
        txtCoachOperator.Text = ""
        txtEnteredBy.Text = ""
        txtDateOfOccurrence.Text = ""
        txtTimeOfOccurrence.Text = ""
        cboBase.SelectedIndex = 0
        cboRoute.SelectedIndex = 0
        txtStopID.Text = ""
        txtStopLocation.Text = ""
        cboBusRun.SelectedIndex = 0
        cboWorkRun.SelectedIndex = 0
        txtBusNumber.Text = ""
        cboBusSeries.SelectedIndex = 0
        cboDayType.SelectedIndex = 0
        cboIssueType.SelectedIndex = 0
        txtDescription.Text = ""

    End Sub

    Protected Sub OnDataBound(sender As Object, e As EventArgs)

        If sender.id = "gvCategoryAndSubCategories" Then
            For i As Integer = gvCategoryAndSubCategories.Rows.Count - 1 To 1 Step -1
                Dim row As GridViewRow = gvCategoryAndSubCategories.Rows(i)
                Dim previousRow As GridViewRow = gvCategoryAndSubCategories.Rows(i - 1)
                For j As Integer = 0 To row.Cells.Count - 1
                    If row.Cells(j).Text = previousRow.Cells(j).Text Then
                        If previousRow.Cells(j).RowSpan = 0 Then
                            If row.Cells(j).RowSpan = 0 Then
                                previousRow.Cells(j).RowSpan += 2
                            Else
                                previousRow.Cells(j).RowSpan = row.Cells(j).RowSpan + 1
                            End If
                            row.Cells(j).Visible = False
                        End If
                    End If
                Next
            Next
        End If

    End Sub

    Private Function GetData(query As String) As DataTable
        Dim dt As New DataTable()
        Dim constr As String = ConfigurationManager.ConnectionStrings("RI2_Conn").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand(query)
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(dt)
                End Using
            End Using
            Return dt
        End Using
    End Function

    Private Sub PrintRecord()

        Try
            If Not IsNumeric(Session("RecordID")) Then Exit Sub
            Dim iID As Integer = Session("RecordID")

            Me.lblWarning.Visible = False

            'Load the detail record based on the value entered or selected.
            sSQL = "spRI2GetIssueRecord"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim iIssueID As New SqlParameter("@iIssueID", SqlDbType.Int)
            oComm.Parameters.Add(iIssueID)
            iIssueID.Direction = ParameterDirection.Input
            iIssueID.Value = iID

            oConn.Open()

            Dim dr As SqlDataReader
            dr = oComm.ExecuteReader()

            dvRecordDetails.DataSource = dr
            dvRecordDetails.DataBind()
            dr.Close()

            dr = oComm.ExecuteReader()

            Do While dr.Read()

                If IsDBNull(dr("BaseName")) Then
                    dvRecordDetails.Rows(9).Cells(0).Visible = False
                    dvRecordDetails.Rows(9).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Route")) Then
                    dvRecordDetails.Rows(10).Cells(0).Visible = False
                    dvRecordDetails.Rows(10).Cells(1).Visible = False
                End If
                If IsDBNull(dr("RouteDirection")) Then
                    dvRecordDetails.Rows(11).Cells(0).Visible = False
                    dvRecordDetails.Rows(11).Cells(1).Visible = False
                End If
                If IsDBNull(dr("StopID")) Then
                    dvRecordDetails.Rows(12).Cells(0).Visible = False
                    dvRecordDetails.Rows(12).Cells(1).Visible = False
                End If
                If IsDBNull(dr("Location")) Then
                    dvRecordDetails.Rows(13).Cells(0).Visible = False
                    dvRecordDetails.Rows(13).Cells(1).Visible = False
                End If
                If IsDBNull(dr("WorkRun")) Then
                    dvRecordDetails.Rows(14).Cells(0).Visible = False
                    dvRecordDetails.Rows(14).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusRun")) Then
                    dvRecordDetails.Rows(15).Cells(0).Visible = False
                    dvRecordDetails.Rows(15).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusNumber")) Then
                    dvRecordDetails.Rows(16).Cells(0).Visible = False
                    dvRecordDetails.Rows(16).Cells(1).Visible = False
                End If
                If IsDBNull(dr("BusSeries")) Then
                    dvRecordDetails.Rows(17).Cells(0).Visible = False
                    dvRecordDetails.Rows(17).Cells(1).Visible = False
                End If
                If IsDBNull(dr("DayType")) Then
                    dvRecordDetails.Rows(18).Cells(0).Visible = False
                    dvRecordDetails.Rows(18).Cells(1).Visible = False
                End If
            Loop

            dvRecordDetails.Visible = True

            oConn.Close()
            dr.Close()
            oComm = Nothing

            ScriptManager.RegisterStartupScript(Me, Page.GetType, "Script", "getModal();", True)

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub Input_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender

        rngDateOfOccurrence.MinimumValue = DateTime.Now.Date.AddYears(-1).ToString("MM/dd/yyyy")
        rngDateOfOccurrence.MaximumValue = DateTime.Now.Date.ToString("MM/dd/yyyy")

    End Sub
End Class