﻿Imports System
Imports System.Web
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Text

Public Class AutoCompleteNameBadge
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim prefixText As String = context.Request.QueryString("q")
        Dim conn As SqlConnection = New SqlConnection

        conn.ConnectionString = ConfigurationManager.ConnectionStrings("RI2_Conn").ConnectionString
        Dim cmd As SqlCommand = New SqlCommand
        cmd.CommandText = ("SELECT DISTINCT CONVERT(char(7), Badge) + ' ' + rtrim(UPPER(Operator)) AS RecordList from dbo.vwRI2IssueRecord where CONVERT(char(7), Badge) + ' ' + rtrim(Operator) like '%' + @SearchText + '%'")
        cmd.Parameters.AddWithValue("@SearchText", prefixText)
        cmd.Connection = conn
        Dim sb As StringBuilder = New StringBuilder
        conn.Open()
        Dim sdr As SqlDataReader = cmd.ExecuteReader
        While sdr.Read
            sb.Append(sdr("RecordList")).Append(Environment.NewLine)
        End While
        conn.Close()
        context.Response.Write(sb.ToString)

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class