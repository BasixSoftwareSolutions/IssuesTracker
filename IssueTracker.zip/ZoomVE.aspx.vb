
Partial Class ZoomVE
    Inherits System.Web.UI.Page

End Class
