﻿Imports System.Data.SqlClient
Imports System.IO
Public Class Users
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sStr As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserName") = "" Or Session("SecurityGroup") <> 1 Then Response.Redirect("Default.aspx")
        fvEditAdmin.Visible = False
        'LoadAdmin()

        If Not IsPostBack Then
            hfUserName.Value = Session("UserName")
            If Request.QueryString("NewAdmin") = "Yes" Then
                fvEditAdmin.ChangeMode(FormViewMode.Insert)
                fvEditAdmin.Visible = True
                Exit Sub
            End If
            If Request.QueryString("ID") <> "" Then
                fvEditAdmin.ChangeMode(FormViewMode.Edit)
                fvEditAdmin.Visible = True
                Session("ID") = Request.QueryString("ID")
            Else
                fvEditAdmin.Visible = False
                Session("ID") = Nothing
            End If

            GridView2.DataBind()
            ddlIssueCategory.Items.Insert(0, "")
        End If

    End Sub

    Private Sub SetControlFocus(ByVal FocusControl As Control)
        Dim Script As New System.Text.StringBuilder()
        Dim clientID As String = FocusControl.ClientID

        With Script
            .Append("<script language='Javascript'>")
            .Append("document.getElementById('")
            .Append(clientID)
            .Append("').focus();")
            .Append("</script>")
        End With
        ClientScript.RegisterStartupScript(GetType(String), "SetControlFocus", Script.ToString())

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(ByVal control As System.Web.UI.Control)
        ' Verifies that the control is rendered 
        ' No code required here. 
    End Sub

    Private Sub cboActive_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboActive.SelectedIndexChanged

        sdsListAdminUsers.SelectCommand = "SELECT * FROM tlkpRI2AdminMembers WHERE Active = " & Me.cboActive.SelectedValue & ""
        GridView2.DataBind()

    End Sub

    Private Sub cmdSaveNewIssue_Click(sender As Object, e As EventArgs) Handles cmdSaveNewIssue.Click

        Try
            If ddlIssueCategory.SelectedValue <> "" AndAlso txtNewIssue.Text <> "" Then
                sSQL = "INSERT INTO tlkpRI2IssueType (Issue, IssueCategoryID, SuppQuestions) VALUES('" & Me.txtNewIssue.Text & "', " & Me.ddlIssueCategory.SelectedValue & ", '" & Me.txtSuppQuestions.Text & "')"
                sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
                Dim oConn As New SqlConnection(sConn)

                Dim oComm As New SqlCommand(sSQL, oConn)
                oComm.CommandType = CommandType.Text

                oConn.Open()
                oComm.ExecuteReader()
                ddlIssueCategory.SelectedValue = 0
                txtNewIssue.Text = ""
                txtSuppQuestions.Text = ""
                oComm = Nothing
                oConn.Close()

                lblSuccess.Visible = True
                Me.lblSuccess.InnerHtml = "<span Class='success' ID='lblSuccess' runat='server' Width='100%' visible='true'><i class='far fa-thumbs-up'></i> New record has been saved...</span>"
            Else
                lblWarning.Visible = True
                Me.lblWarning.InnerHtml = "<span Class='warning' ID='lblWarning' runat='server' Width='100%' visible='true'><i class='far fa-thumbs-down'></i> No record to save...</span>"
            End If

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub lbSaveCannedVerbage_Click(sender As Object, e As EventArgs) Handles lbSaveCannedVerbage.Click

        Try
            If ddlIssueCategoryAbbrev.SelectedValue <> "" AndAlso txtButtonText.Text <> "" AndAlso txtCannedText.Text <> "" Then
                sSQL = "INSERT INTO tlkpRI2CannedText (IssueCategoryID, ButtonText, CannedText) VALUES('" & Me.ddlIssueCategoryAbbrev.SelectedValue & "', '" & Me.txtButtonText.Text & "', '" & txtCannedText.Text & "' )"
                sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
                Dim oConn As New SqlConnection(sConn)

                Dim oComm As New SqlCommand(sSQL, oConn)
                oComm.CommandType = CommandType.Text

                oConn.Open()
                oComm.ExecuteReader()
                ddlIssueCategoryAbbrev.SelectedValue = 0
                txtButtonText.Text = ""
                txtCannedText.Text = ""
                ddlIssueCategoryAbbrev.SelectedValue = ""
                oComm = Nothing
                oConn.Close()

                gvCannedVerbage.DataBind()

                lblSuccess.Visible = True
                Me.lblSuccess.InnerHtml = "<span Class='success' ID='lblSuccess' runat='server' Width='100%' visible='true'><i class='far fa-thumbs-up'></i> New record has been saved...</span>"
            Else
                lblWarning.Visible = True
                Me.lblWarning.InnerHtml = "<span Class='warning' ID='lblWarning' runat='server' Width='100%' visible='true'><i class='far fa-thumbs-down'></i> No record to save...</span>"
            End If

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub

    Private Sub cboDepartments_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDepartments.SelectedIndexChanged

        sSQL = "Select dbo.tlkpRI2IssueType.ID, " &
            "RTrim(dbo.tlkpRI2IssueType.Active) As Active, " &
            "RTrim(tlkpRI2IssueCategory.IssueCategory) As IssueCategory, " &
            "RTrim(tlkpRI2IssueType.Issue) As Issue, " &
            "RTrim(tlkpRI2IssueType.IssueCategoryID) As IssueCategoryID, " &
            "RTrim(tlkpRI2IssueCategory.IssueCategoryAbbrev) As IssueCategoryAbbrev, " &
            "RTrim(tlkpRI2IssueType.Message) As Message, " &
            "RTrim(tlkpRI2IssueType.SuppQuestions) As SuppQuestions " &
            "From dbo.tlkpRI2IssueType " &
            "INNER Join dbo.tlkpRI2IssueCategory ON dbo.tlkpRI2IssueType.IssueCategoryID = dbo.tlkpRI2IssueCategory.ID " &
            "WHERE dbo.tlkpRI2IssueType.IssueCategoryID = " & Me.cboDepartments.SelectedValue & " " &
            "AND dbo.tlkpRI2IssueType.Active = " & Me.cboActiveIssues.SelectedValue & " " &
            "ORDER BY IssueCategoryID"
        sdsIssueList.SelectCommand = sSQL
        gvIssueCategory.DataBind()

    End Sub

    Private Sub cboActiveIssues_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboActiveIssues.SelectedIndexChanged

        If Me.cboDepartments.SelectedValue = "Departments" Then
            sdsIssueList.SelectCommand = "SELECT dbo.tlkpRI2IssueType.ID, " &
                "RTRIM(dbo.tlkpRI2IssueType.Active) AS Active, " &
                "RTRIM(tlkpRI2IssueCategory.IssueCategory) AS IssueCategory, " &
                "RTRIM(tlkpRI2IssueType.Issue) AS Issue, " &
                "RTRIM(tlkpRI2IssueType.IssueCategoryID) AS IssueCategoryID, " &
                "RTRIM(tlkpRI2IssueCategory.IssueCategoryAbbrev) AS IssueCategoryAbbrev, " &
                "RTrim(tlkpRI2IssueType.Message) As Message, " &
                "RTRIM(tlkpRI2IssueType.SuppQuestions) AS SuppQuestions " &
                "FROM dbo.tlkpRI2IssueType " &
                "INNER JOIN dbo.tlkpRI2IssueCategory ON dbo.tlkpRI2IssueType.IssueCategoryID = dbo.tlkpRI2IssueCategory.ID " &
                "WHERE dbo.tlkpRI2IssueType.Active = " & Me.cboActiveIssues.SelectedValue & " ORDER BY IssueCategoryID "
        Else
            sdsIssueList.SelectCommand = "SELECT dbo.tlkpRI2IssueType.ID, " &
                "RTRIM(dbo.tlkpRI2IssueType.Active) AS Active, " &
                "RTRIM(tlkpRI2IssueCategory.IssueCategory) AS IssueCategory, " &
                "RTRIM(tlkpRI2IssueType.Issue) AS Issue, " &
                "RTRIM(tlkpRI2IssueType.IssueCategoryID) AS IssueCategoryID, " &
                "RTRIM(tlkpRI2IssueCategory.IssueCategoryAbbrev) AS IssueCategoryAbbrev, " &
                "RTrim(tlkpRI2IssueType.Message) As Message, " &
                "RTRIM(tlkpRI2IssueType.SuppQuestions) AS SuppQuestions " &
                "FROM dbo.tlkpRI2IssueType " &
                "INNER JOIN dbo.tlkpRI2IssueCategory ON dbo.tlkpRI2IssueType.IssueCategoryID = dbo.tlkpRI2IssueCategory.ID " &
                "WHERE dbo.tlkpRI2IssueType.IssueCategoryID = " & Me.cboDepartments.SelectedValue & " " &
                "AND dbo.tlkpRI2IssueType.Active = " & Me.cboActiveIssues.SelectedValue & " " &
                "ORDER BY IssueCategoryID"
        End If

        gvIssueCategory.DataBind()

    End Sub

    Private Sub btnSaveNewRoute_Click(sender As Object, e As EventArgs) Handles btnSaveNewRoute.Click

        Try
            sSQL = "INSERT INTO tlkpRI2RouteAssignments (Route, AdminID) VALUES('" & Me.txtNewRoute.Text & "', " & Me.ddlNewRouteAdmin.SelectedValue & ")"
            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            oComm.ExecuteReader()
            ddlNewRouteAdmin.SelectedValue = 0
            txtNewRoute.Text = ""
            oComm = Nothing
            oConn.Close()

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub
End Class