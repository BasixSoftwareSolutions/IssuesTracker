Imports System.Web.Security
Imports System.Web.UI.Page
Imports System.Data.SqlClient
Imports System.Data

Namespace RI2v2
    Public Module Utilities
        Dim sSQL As String
        Dim sConn As String

        Public Function fStripSpecialChar(ByVal des As String) As String
            'Remove special characters from string
            Dim sStr As String
            Dim intCounter As Integer
            Dim arrSpecialChar() As String = {"<", ">", "%", "&", "'"}
            sStr = des
            intCounter = 0
            Dim i As Integer
            For i = 0 To arrSpecialChar.Length - 1
                Do Until intCounter = 29
                    des = Replace(sStr, arrSpecialChar(i), "")
                    intCounter = intCounter + 1
                    sStr = des
                Loop
                intCounter = 0
            Next
            If sStr = Nothing Then sStr = ""
            Return sStr
        End Function

        Public Sub ShowMsgBox(ByVal sMessage As String)
            Dim strMsg As String = ""

            strMsg = "<script language='javascript'>"
            strMsg += "alert('" & sMessage & "');"
            strMsg += "<" & "/script>"

        End Sub

        Public Function IsAppUser(ByVal sNTUser As String) As String
            'Used to determine if the user has a valid NT account
            'Returns string value

            sSQL = "spRI2GetUserLogin"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim sUserName As SqlParameter = oComm.Parameters.Add("@chrUserName", SqlDbType.Char)
            sUserName.Value = sNTUser

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()
            If dr.HasRows Then
                IsAppUser = sNTUser
            Else
                IsAppUser = ""
            End If

        End Function


        Public Function CaseloadAuthenticate(ByVal pUserName As String, ByVal pPassword As String) As Boolean

            sSQL = "spGetCaseloadLogin"

            sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            Dim sUserName As SqlParameter = oComm.Parameters.Add("@chrUserName", SqlDbType.Char)
            sUserName.Value = pUserName
            Dim sPassword As SqlParameter = oComm.Parameters.Add("@chrPassword", SqlDbType.Char)
            sPassword.Value = pPassword

            oConn.Open()

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()
            If dr.HasRows Then
                CaseloadAuthenticate = True
            Else
                CaseloadAuthenticate = False
            End If
        End Function
        Public Function sqlDate(ByVal sDate As String) As String
            If sDate = "" Then
                sqlDate = "Null"
            Else
                sqlDate = "#" & sDate & "#"
            End If
        End Function
        Public Function getDate(ByVal oDate As Object) As String
            If oDate.GetType Is GetType(DateTime) Then
                Return oDate.ToShortDateString()
            Else
                Return ""
            End If
        End Function
        Public Function ConvertTime(ByVal oTime As Object) As String
            If oTime.GetType Is GetType(DateTime) Then
                Return oTime.ToShortTimeString
            Else
                Return ""
            End If
        End Function
        Public Function ReplaceQuotes(ByVal sStringText As String) As String
            Dim sText As String

            sText = Replace(sStringText, """", "")
            sText = Replace(sText, "'", "''")
            ReplaceQuotes = sText

        End Function
    End Module
End Namespace
