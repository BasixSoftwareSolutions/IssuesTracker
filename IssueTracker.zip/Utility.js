    function clickMe() {
        alert("Here");
    }
    function printRecordAdmin() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdPrint');
        clickbutton.click();
    }

    function validateAlpha(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8 || charCode == 32 || charCode == 188)
            return true;
        else
            return false;
    }

    function isNumber(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    function openclose() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_toggle');
        clickbutton.click();
    }

    function getEmailForm() {
        var clickbutton = document.getElementById('btnEmail');
        clickbutton.click();
    }
    function getAdminSaveBtn() {
        var clickbutton = document.getElementById('ContentPlaceHolder1_cmdSave');
        clickbutton.click();
    }
    function getSavedMessage() {
        var clickbutton = document.getElementById('btnEmail');
        clickbutton.click();
    }

	function OpenDetail(prmID)
	{
		window.location='WorkSheet.aspx?ID=' + prmID
	}
		
	function OpenViewMemo()
	{
	var objWin, varURL, varID
	varURL = 'MemoReport.aspx';
        objWin = window.open(varURL, '', 'left=200,top=100,toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=725,height=800');
	}
    
	function EmailRecord()
	{
	var objWin, varURL
    varURL = 'EmailForm.aspx?'
    const win = window
    const w = 450
    const h = 725
    const y = win.top.outerHeight / 2 + win.top.screenY - (h / 2);
    const x = win.top.outerWidth / 2 + win.top.screenX - (w / 2);    
    objWin = window.open(varURL, '', 'toolbar=false,status=false,directories=false,menubar=false,scrollbars=yes,resizable=yes,copyhistory=false,width=' + w + ', height=' + h + ', top=' + y + ', left=' + x);
    }

	function DoBlur(fld) {
    fld.className='normalfld';
    }

    function DoFocus(fld) {
    fld.className = 'focusfld';
    }
        
    function getIssueCategory() {

        var ctlBadge = document.getElementById('ContentPlaceHolder1_txtBadge');
        if (ctlBadge.value == "Type in Badge Number") {
            alert("Please enter a badge");
            document.getElementById("ContentPlaceHolder1_txtBadge").focus();
            return false;
            }            
        var ctlDateOfOccurrence = document.getElementById('ContentPlaceHolder1_txtDateOfOccurrence');
        if (ctlDateOfOccurrence.value == "mm/dd/yyyy") {
            alert("Please enter a date");
            document.getElementById("ContentPlaceHolder1_txtDateOfOccurrence").focus();
            return false;
        }
        var ctlCoachOperator = document.getElementById('ContentPlaceHolder1_txtCoachOperator');
        if (ctlCoachOperator.value == "Type in Coach Operator Name") {
            alert("Please enter a Coach Operator Name");
            document.getElementById("ContentPlaceHolder1_txtCoachOperator").focus();
            return false;
        }
        var ctlTimeOfOccurrence = document.getElementById('ContentPlaceHolder1_txtTimeOfOccurrence');
        if (ctlTimeOfOccurrence.value == "Military format") {
            alert("Please enter a Time");
            document.getElementById("ContentPlaceHolder1_txtTimeOfOccurrence").focus();
            return false;
        }
        var ctlEnteredBy = document.getElementById('ContentPlaceHolder1_txtEnteredBy');
        if (ctlEnteredBy.value == "Type in Entered By Name") {
            alert("Please enter a Name");
            document.getElementById("ContentPlaceHolder1_txtEnteredBy").focus();
            return false;
        }
        var clickbutton = document.getElementById('ContentPlaceHolder1_btnGo');
        clickbutton.click();
    }

    function checkEmpty(val, txtbox) {       
        var ctl = document.getElementById(txtbox)
        if (val != "") {
            ctl.style.backgroundColor = "White";
        }
        //else {
            //if (ctl.required = true) {
                //ctl.style.backgroundColor = "Red";
            //}            
        //}
    }



     