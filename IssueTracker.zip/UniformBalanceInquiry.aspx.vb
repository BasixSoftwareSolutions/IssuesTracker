﻿Imports System.Data.SqlClient
Imports System.Data
Public Class UniformBalanceInquiry
    Inherits System.Web.UI.Page
    Dim sConn As String
    Dim sSQL As String
    Dim sStr As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load, Me.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Request.QueryString("Badge") <> "" Then
                txtBadge.Text = Request.QueryString("Badge")
            End If
            ClientScript.RegisterHiddenField("_EVENTTARGET", "LinkButton1")
            txtBadge.Focus()
        Else
            GetBalance()
            lblBalanceAmt.Visible = True
            lblBalance.Visible = True
            GridView1.Visible = True
        End If

    End Sub

    Private Sub GetBalance()
        Dim bRecordExist As Boolean

        Try
            bRecordExist = False
            lblOperator.Text = ""
            lblBalanceAmt.Text = ""
            If Not IsDBNull(txtBadge.Text) Then
                sSQL = "SELECT sum(CreditAmount - DebitAmount) as Balance, [Name], EmployeeID, Status "
                sSQL = sSQL & "FROM dbo.vwUNInvoiceInquery "
                sSQL = sSQL & "GROUP BY EmployeeID, [Name], Status "
                sSQL = sSQL & "HAVING EmployeeID = '" & txtBadge.Text & "'"

                sConn = System.Configuration.ConfigurationManager.AppSettings("RI2_Conn")
                Dim oConn As New SqlConnection(sConn)
                Dim oComm As New SqlCommand(sSQL, oConn)
                oComm.CommandType = CommandType.Text

                oConn.Open()

                Dim dr As SqlDataReader

                dr = oComm.ExecuteReader()

                Do While dr.Read()
                    If Not IsDBNull(dr("Balance")) Then
                        bRecordExist = True
                        lblBalanceAmt.Visible = True
                        lblBalance.Visible = True
                        lblBalanceAmt.Text = String.Format("{0:c}", dr("Balance"))
                        lblOperator.Text = dr("Name")
                        OperatorName.Visible = True
                        lblStatus.Visible = True
                        lblStatusLabel.Visible = True
                        lblStatus.Text = dr("Status")
                        If CInt(lblBalanceAmt.Text) < 0 Then
                            lblBalanceAmt.ForeColor = System.Drawing.Color.Red
                        Else
                            lblBalanceAmt.ForeColor = System.Drawing.Color.Black
                        End If
                    Else
                        lblOperator.Text = "No Balance Exist!"
                        OperatorName.Visible = True
                        lblBalanceAmt.Visible = False
                        lblBalance.Visible = False
                        lblStatus.Visible = False
                        lblStatusLabel.Visible = False
                    End If
                Loop

                oConn.Close()
                oComm = Nothing

            End If

        Catch ex As Exception
            sStr = "Source: " & ex.Source & "" & vbCrLf
            sStr = "Message: " & ex.Message & "" & vbCrLf
            Response.Write("<script>alert('" & sStr & "');</script>")
        End Try

    End Sub
    Protected Sub cmdBalance_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBalance.Click

        GetBalance()

    End Sub

End Class
